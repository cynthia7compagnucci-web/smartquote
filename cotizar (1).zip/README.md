# CotizAR 📊✨
### Presupuestador Inteligente con Sincronización en la Nube (Firebase)

¡Felicitaciones por completar la **Fase 1**! Este repositorio contiene el código fuente completo de **CotizAR**, una aplicación web profesional de alto rendimiento diseñada para crear, calcular y almacenar cotizaciones comerciales de forma segura.

Este archivo `README.md` es la carta de presentación de tu proyecto. Al subirlo a **GitHub**, se mostrará automáticamente en la página principal del repositorio. Sirve para que tú, tus colaboradores o futuros clientes entiendan qué es este sistema y cómo ponerlo en marcha desde cero de manera 100% gratuita.

---

## 🚀 ¿Qué deberías hacer con este archivo README.md?

Este archivo debe quedarse en la **raíz de tu proyecto** (junto a `package.json`). Cuando subas tu código a GitHub, cumplirá las siguientes funciones clave:
1. **Documentación Personal:** Te servirá de guía paso a paso para cuando quieras retomar el proyecto o instalarlo en otra computadora.
2. **Presentación Profesional:** Si muestras este proyecto en tu portafolio, cualquier reclutador o colega podrá ver que trabajas con estándares profesionales y metodologías claras.
3. **Instrucciones de Despliegue:** Explica cómo conectar la base de datos de Firebase y cómo levantar la aplicación en producción gratis.

---

## 🛠️ Guía de Inicio Rápido (Local)

Para ejecutar esta aplicación en tu computadora de manera local, sigue estos sencillos pasos:

### Prerrequisitos
Asegúrate de tener instalado [Node.js](https://nodejs.org/) (versión 18 o superior).

### Pasos
1. **Descomprimir el ZIP** que descargaste de AI Studio en una carpeta de tu computadora.
2. **Abrir la terminal** (o consola de comandos) dentro de esa carpeta.
3. **Instalar las dependencias** necesarias del proyecto:
   ```bash
   npm install
   ```
4. **Iniciar el servidor de desarrollo** local:
   ```bash
   npm run dev
   ```
5. Abre tu navegador web e ingresa a la dirección que te indique la consola (normalmente `http://localhost:3000` o `http://localhost:5173`).

---

## 📁 Estructura del Proyecto

* **`/src`**: Contiene todo el código de la aplicación (componentes React, lógica de presupuesto y hooks de conexión).
  * **`src/firebase.ts`**: Inicialización del SDK de Firebase configurado para evitar micro-cortes mediante técnicas de comunicación optimizada (*Long Polling*).
  * **`src/hooks/useFirebase.ts`**: Hook personalizado para manejar el inicio de sesión con Google, sincronización de perfiles y operaciones de base de datos (guardado, lectura y eliminación).
  * **`src/components/FirebaseSyncPanel.tsx`**: Panel visual interactivo de sincronización en la nube integrado en la barra lateral del presupuestador.
* **`firestore.rules`**: Reglas de seguridad robustas (*Zero-Trust*) que protegen la base de datos de accesos indebidos o fraudes de descuento.
* **`firebase-blueprint.json`**: Estructura de colecciones y esquemas lógicos recomendados para Firestore.

---

## 🔒 Seguridad e Integración con Firebase

Este proyecto está pre-configurado para conectarse a tu base de datos de Firestore de forma segura. 
* Los datos de conexión están definidos en el archivo `firebase-applet-config.json` (se incluyen de manera local y están protegidos por reglas del servidor).
* Las reglas definidas en `firestore.rules` aseguran que:
  * **Aislamiento Multitenant:** Un usuario del inquilino A jamás podrá ver ni modificar presupuestos o clientes del inquilino B.
  * **Integridad Financiera:** Ninguna cotización puede superar el **50% de descuento global** impuesto por el servidor.
  * **Inmutabilidad Temporal:** La fecha de creación (`createdAt`) de cada cotización es validada con la hora real del servidor de Google, impidiendo manipulaciones retroactivas.

---

## 🌐 Próximas Fases: Subir a GitHub y Desplegar Gratis

Aquí tienes el plan de acción para que completes las siguientes fases de tu sitio web:

### Paso 1: Crear tu repositorio en GitHub (Gratis)
1. Ve a [GitHub](https://github.com/) e inicia sesión.
2. Haz clic en el botón **"New"** (Nuevo) para crear un repositorio.
3. Nómbralo como `CotizAR` y déjalo como **Público** o **Privado** según prefieras. *No selecciones inicializar con README ni .gitignore, ya que este proyecto ya cuenta con ellos.*

### Paso 2: Subir el código desde tu computadora
Si eres principiante, te recomendamos descargar [GitHub Desktop](https://desktop.github.com/) (es una herramienta visual muy fácil de usar):
1. Abre **GitHub Desktop** y arrastra la carpeta descomprimida del proyecto allí.
2. Te sugerirá "añadir un repositorio local". Haz clic en esa opción.
3. Escribe un mensaje de confirmación (ej: `Primer commit de CotizAR`) y haz clic en **Commit to main**.
4. Haz clic en **Publish repository** (Publicar repositorio) para conectarlo automáticamente con tu cuenta de GitHub en internet. ¡Y listo! Tu código estará en la nube de GitHub.

### Paso 3: Desplegar la Web Gratis en Producción (Hosting)
Una vez que el código esté en tu GitHub, puedes subir la web de forma 100% gratuita utilizando servicios de alta velocidad como **Vercel** o **Netlify**:
1. Entra a [Vercel](https://vercel.com/) y regístrate con tu cuenta de GitHub.
2. Haz clic en **"Add New"** > **"Project"**.
3. Importa tu repositorio `CotizAR`.
4. Haz clic en **Deploy** (Desplegar). Vercel compilará tu aplicación de React + Vite automáticamente en menos de un minuto y te entregará un enlace web público (`https://cotizar.vercel.app`) para que cualquier persona en el mundo pueda ingresar y usar la aplicación con su cuenta de Google.

---
💻 *Desarrollado con pasión como un presupuestador moderno, robusto y escalable de alto rendimiento comercial.*
