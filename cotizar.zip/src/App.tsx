/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  calculateBudgetTotals, 
  BudgetItemInput, 
  roundToTwoDecimals,
  ItemType
} from './utils/budget';
import FirebaseSyncPanel from './components/FirebaseSyncPanel';
import { 
  Briefcase, 
  User, 
  Users, 
  Plus, 
  Trash2, 
  Calculator, 
  FileCode, 
  Database, 
  CheckCircle2, 
  AlertCircle, 
  Copy, 
  Layers, 
  DollarSign, 
  Percent, 
  Settings, 
  Sparkles,
  RefreshCw,
  Clock,
  HardDrive,
  FileSpreadsheet,
  X,
  TrendingUp,
  Scale,
  Receipt,
  PiggyBank,
  ChevronRight,
  ShieldCheck,
  Check,
  Info
} from 'lucide-react';

// --- DATOS PRECARGADOS MULTI-TENANT ---
const DEFAULT_TENANTS = [
  { id: 't1', name: 'Estudio Creativo Sur (Empresa)', type: 'COMPANY' as const, usersCount: 5 },
  { id: 't2', name: 'Laura Gómez (Freelancer)', type: 'FREELANCER' as const, usersCount: 1 }
];

const DEFAULT_USERS = [
  { id: 'u1', name: 'Laura Gómez (Independiente)', role: 'ADMIN', tenantId: 't2', avatar: 'LG' },
  { id: 'u2', name: 'Carlos Spahn (CEO / Admin)', role: 'ADMIN', tenantId: 't1', avatar: 'CS' },
  { id: 'u3', name: 'Sofía Martínez (Ejecutiva de Ventas)', role: 'VENDEDOR', tenantId: 't1', avatar: 'SM' }
];

const DEFAULT_CLIENTS = [
  { id: 'c1', name: 'Cynthia Compagnucci', companyName: 'Globant Argentina S.A.', email: 'cynthia@globant.com', phone: '+54 11 4843-0000', taxId: '30-71114524-8', tenantId: 't1' },
  { id: 'c2', name: 'Andrés Kovalsky', companyName: 'Aluar Aluminio S.A.', email: 'akovalsky@aluar.com.ar', phone: '+54 11 5281-2200', taxId: '30-50004922-1', tenantId: 't1' },
  { id: 'c3', name: 'Estudio Jurídico Pereyra', companyName: 'Pereyra & Asociados', email: 'pereyra@derecho.com.ar', phone: '+54 261 423-1122', taxId: '20-18454222-9', tenantId: 't2' }
];

const IVA_OPTIONS = [
  { value: 21.0, label: '21% (Tasa General Argentina)' },
  { value: 10.5, label: '10.5% (Tasa Comercial/Bienes de Uso)' },
  { value: 27.0, label: '27% (Servicios Públicos Especiales)' },
  { value: 0.0, label: '0% (Exento / Exportación de Servicios)' }
];

// Presupuestos modelo/plantilla para inicializar con excelente nivel visual
const DEFAULT_ITEMS: BudgetItemInput[] = [
  {
    id: 'item-1',
    name: 'Desarrollo de API Gateway & Backend Microservices',
    type: 'HOURLY',
    hourlyRate: 55,
    hours: 120,
    costoBase: 6600, // 55 * 120
    margenGanancia: 45, // 45% de markup de utilidad deseada
    alicuotaIva: 21.0,
    descuento: 0
  },
  {
    id: 'item-2',
    name: 'Infraestructura Cloud (AWS ECS, RDS Postgres Enterprise)',
    type: 'MATERIAL',
    unitCost: 180,
    quantity: 12,
    unitLabel: 'meses',
    costoBase: 2160, // 180 * 12
    margenGanancia: 15, // 15% margen de reventa
    alicuotaIva: 21.0,
    descuento: 5 // 5% descuento por volumen
  },
  {
    id: 'item-3',
    name: 'Prototipo UX/UI de Alta Fidelidad & User Testing',
    type: 'FIXED',
    fixedCost: 2800,
    costoBase: 2800,
    margenGanancia: 35, // 35% margen de utilidad
    alicuotaIva: 0.0, // Exportación de servicios / Exento de IVA
    descuento: 10 // 10% descuento de cupón comercial
  }
];

export default function App() {
  const [activeTab, setActiveTab] = useState<'calculator' | 'schema' | 'architecture'>('calculator');
  
  // --- Estados de Negocio & Control de Acceso ---
  const [selectedTenantId, setSelectedTenantId] = useState<string>('t1');
  const [selectedUserId, setSelectedUserId] = useState<string>('u2');
  const [selectedClientId, setSelectedClientId] = useState<string>('c1');
  
  // --- Cabecera del Presupuesto ---
  const [budgetTitle, setBudgetTitle] = useState<string>('Plataforma Inteligente de Cómputo Comercial - SmartQuote');
  const [budgetCode, setBudgetCode] = useState<string>('COT-2026-0089');
  const [budgetCurrency, setBudgetCurrency] = useState<string>('USD');
  const [budgetNotes, setBudgetNotes] = useState<string>('Condiciones Comerciales: Anticipo del 40% al inicio del proyecto. El resto se divide en 3 milestones funcionales verificables.');

  // --- Descuento Global (0% a 50%) ---
  const [globalDiscount, setGlobalDiscount] = useState<number>(0);

  // --- Lista de Items en Tiempo Real ---
  const [items, setItems] = useState<BudgetItemInput[]>(DEFAULT_ITEMS);

  // --- Estados del Formulario de Carga del Creador ---
  const [itemName, setItemName] = useState<string>('');
  const [itemType, setItemType] = useState<ItemType>('HOURLY');
  
  // Parametrización por Rubro
  const [hourlyRate, setHourlyRate] = useState<number>(50);
  const [hoursCount, setHoursCount] = useState<number>(40);
  
  const [materialUnitCost, setMaterialUnitCost] = useState<number>(100);
  const [materialQuantity, setMaterialQuantity] = useState<number>(10);
  const [materialLabel, setMaterialLabel] = useState<string>('unidades');
  
  const [fixedServiceCost, setFixedServiceCost] = useState<number>(1500);

  // Estructura Financiera por Ítem
  const [profitMargin, setProfitMargin] = useState<number>(35); // (%)
  const [ivaRate, setIvaRate] = useState<number>(21.0); // (%)
  const [itemDiscount, setItemDiscount] = useState<number>(0); // (%)

  // --- UI feedback states ---
  const [isMarginModalOpen, setIsMarginModalOpen] = useState<boolean>(false);
  const [copiedTextType, setCopiedTextType] = useState<string | null>(null);

  // --- Computed States (Lógica Central de Cálculo en Tiempo Real) ---
  const currentTenant = useMemo(() => {
    return DEFAULT_TENANTS.find(t => t.id === selectedTenantId) || DEFAULT_TENANTS[0];
  }, [selectedTenantId]);

  const filteredUsers = useMemo(() => {
    return DEFAULT_USERS.filter(u => u.tenantId === selectedTenantId);
  }, [selectedTenantId]);

  const currentClient = useMemo(() => {
    return DEFAULT_CLIENTS.find(c => c.id === selectedClientId) || DEFAULT_CLIENTS[0];
  }, [selectedClientId]);

  // Asegurar consistencia de sesión simulada al cambiar de inquilino (Tenant)
  React.useEffect(() => {
    if (filteredUsers.length > 0) {
      setSelectedUserId(filteredUsers[0].id);
    }
  }, [selectedTenantId, filteredUsers]);

  /**
   * Cálculo Avanzado de Totales en Tiempo Real:
   * 1. Toma todos los ítems agregados individualmente.
   * 2. Calcula de forma aislada: costoBase, margenGanancia, descuento de ítem, alícuota de IVA.
   * 3. Aplica de manera matemática el "Descuento Global" (0% a 50%) sobre el subtotal resultante,
   *    recalculando proporcionalmente la ganancia comercial real y la carga impositiva acumulada.
   */
  const computedTotals = useMemo(() => {
    // 1) Obtener métricas base directo del motor utilitario puro
    const baseReport = calculateBudgetTotals(items);

    // 2) Si existe descuento global, ajustar proporcionalmente
    const factorDescuento = 1 - (globalDiscount / 100);
    
    // El costo total del proyecto se mantiene idéntico (el costo de producción no cambia por hacer un descuento)
    const costoTotal = baseReport.costoTotal;

    // Recalcular subtotal de venta aplicando descuento global
    const subtotalVentaTotalRaw = baseReport.subtotalVentaTotal * factorDescuento;
    const subtotalVentaTotal = roundToTwoDecimals(subtotalVentaTotalRaw);

    // Recalcular IVA de cada item aplicando el descuento global
    let ivaTotalMasivo = 0;
    const ivaTotalPorTasa: Record<string, number> = {};

    items.forEach((item) => {
      const costoBase = Math.max(0, item.costoBase || 0);
      const margen = Math.max(0, item.margenGanancia || 0);
      const descuentoItemPct = Math.max(0, Math.min(100, item.descuento || 0));
      const alicuota = Math.max(0, item.alicuotaIva || 0);

      // Precio unitario planeado
      const precioSugerido = costoBase * (1 + (margen / 100));
      const subtotalItemConDctoPropio = precioSugerido * (1 - (descuentoItemPct / 100));
      
      // Aplicar descuento global
      const subtotalItemDefinitivo = subtotalItemConDctoPropio * factorDescuento;
      const montoIvaItem = subtotalItemDefinitivo * (alicuota / 100);

      ivaTotalMasivo += montoIvaItem;

      const tasaKey = alicuota.toFixed(1);
      if (!ivaTotalPorTasa[tasaKey]) {
        ivaTotalPorTasa[tasaKey] = 0;
      }
      ivaTotalPorTasa[tasaKey] += montoIvaItem;
    });

    // Redondear el IVA
    const ivaAgrupadoRedondeado: Record<string, number> = {};
    for (const [tasa, monto] of Object.entries(ivaTotalPorTasa)) {
      ivaAgrupadoRedondeado[tasa] = roundToTwoDecimals(monto);
    }
    const totalIvaDefinitivo = roundToTwoDecimals(ivaTotalMasivo);

    // Precio final al cliente = Subtotal descontado + IVA descontado
    const precioFinalVenta = roundToTwoDecimals(subtotalVentaTotal + totalIvaDefinitivo);

    // Ganancia Neta Realizada = Subtotal de Venta (sin IVA) - Costo Total de Producción
    // Ésto nos dice exactamente cuánto dinero "limpio" queda en el negocio tras el global discount
    const gananciaNetaTotal = roundToTwoDecimals(subtotalVentaTotal - costoTotal);

    // Porcentaje de Rentabilidad Real sobre ventas = (Ganancia Neta / Subtotal Venta) * 100
    const margenRealPct = subtotalVentaTotal > 0 
      ? roundToTwoDecimals((gananciaNetaTotal / subtotalVentaTotal) * 100) 
      : 0;

    return {
      costoTotal,
      gananciaNetaTotal,
      subtotalVentaTotal,
      ivaTotalPorTasa: ivaAgrupadoRedondeado,
      ivaTotalMasivo: totalIvaDefinitivo,
      precioFinalVenta,
      margenRealPct
    };
  }, [items, globalDiscount]);

  // Agregar Ítem desde el formulario
  const handleFormAddItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!itemName.trim()) return;

    let calculadoCostoBase = 0;
    if (itemType === 'HOURLY') {
      calculadoCostoBase = hourlyRate * hoursCount;
    } else if (itemType === 'MATERIAL') {
      calculadoCostoBase = materialUnitCost * materialQuantity;
    } else {
      calculadoCostoBase = fixedServiceCost;
    }

    const nuevoItem: BudgetItemInput = {
      id: `item-loaded-${Date.now()}`,
      name: itemName,
      type: itemType,
      costoBase: Math.max(0, calculadoCostoBase),
      margenGanancia: Math.max(0, profitMargin),
      alicuotaIva: ivaRate,
      descuento: Math.max(0, Math.min(100, itemDiscount)),
      
      // Especificidades del Rubro
      ...(itemType === 'HOURLY' && { hourlyRate, hours: hoursCount }),
      ...(itemType === 'MATERIAL' && { unitCost: materialUnitCost, quantity: materialQuantity, unitLabel: materialLabel }),
      ...(itemType === 'FIXED' && { fixedCost: fixedServiceCost })
    };

    setItems([...items, nuevoItem]);
    
    // Limpieza de campos parciales para agilidad de carga
    setItemName('');
    setItemDiscount(0);
  };

  // Quitar Ítem
  const handleDeleteItem = (idToDelete: string) => {
    setItems(items.filter(item => item.id !== idToDelete));
  };

  // Modificar Ítem Directo desde la Grilla (Edición Rápida Reactiva)
  const handleQuickUpdateItem = (id: string, field: keyof BudgetItemInput, val: any) => {
    setItems(prevItems => {
      return prevItems.map(item => {
        if (item.id !== id) return item;

        const updated = { ...item, [field]: val };

        // Recalcular costoBase de acuerdo al tipo de rubro modificado
        if (updated.type === 'HOURLY') {
          const rate = field === 'hourlyRate' ? Number(val) : (updated.hourlyRate || 0);
          const hrs = field === 'hours' ? Number(val) : (updated.hours || 0);
          updated.costoBase = rate * hrs;
        } else if (updated.type === 'MATERIAL') {
          const uCost = field === 'unitCost' ? Number(val) : (updated.unitCost || 0);
          const qty = field === 'quantity' ? Number(val) : (updated.quantity || 0);
          updated.costoBase = uCost * qty;
        } else if (updated.type === 'FIXED' && field === 'fixedCost') {
          updated.costoBase = Number(val);
        }

        return updated;
      });
    });
  };

  // Autocompletar con ajustes por Rubro Comunes en LATAM para pruebas ágiles
  const handleSetPresetItem = (preset: 'consultoria' | 'servidores' | 'licencias') => {
    if (preset === 'consultoria') {
      setItemName('Consultoría de Arquitectura de Base de Datos PostgreSQL');
      setItemType('HOURLY');
      setHourlyRate(65);
      setHoursCount(40);
      setProfitMargin(40);
      setIvaRate(21.0);
    } else if (preset === 'servidores') {
      setItemName('Instancia Cloud SQL dedicadas en ambiente Cloud Run');
      setItemType('MATERIAL');
      setMaterialUnitCost(210);
      setMaterialQuantity(6);
      setMaterialLabel('meses');
      setProfitMargin(15);
      setIvaRate(21.0);
    } else {
      setItemName('Servicio Cerrado de Setup CICD & Seguridad Perimetral');
      setItemType('FIXED');
      setFixedServiceCost(3500);
      setProfitMargin(50);
      setIvaRate(0.0); // Exento de IVA
    }
  };

  // Ejecutar simulación de copiado de cotización formateada para enviar por WhatsApp o Email
  const handleCopyFormattedQuote = () => {
    const formattedText = `
📄 COTIZACIÓN COMERCIAL: ${budgetCode}
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Título: ${budgetTitle}
Cliente: ${currentClient.companyName || currentClient.name} (${currentClient.name})
Inquilino (Workspace): ${currentTenant.name}

DETALLE DE COSTOS Y SERVICIOS:
${items.map((it, idx) => `
• [${it.type}] ${it.name}
  Costo Base: ${budgetCurrency} ${it.costoBase} | Margen: ${it.margenGanancia}% | Dcto: ${it.descuento}%
  Subtotal Neto: ${budgetCurrency} ${roundToTwoDecimals(it.costoBase * (1 + (it.margenGanancia/100)) * (1 - (it.descuento/100)))}
`).join('')}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
RESUMEN DE RENTABILIDAD Y TOTALES:
• Descuento Global Aplicado: ${globalDiscount}%
• Costos Totales de Producción: ${budgetCurrency} ${computedTotals.costoTotal}
• Subtotal Neto de Venta: ${budgetCurrency} ${computedTotals.subtotalVentaTotal}
• IVA Acumulado: ${budgetCurrency} ${computedTotals.ivaTotalMasivo}
• PRECIO FINAL DE VENTA: ${budgetCurrency} ${computedTotals.precioFinalVenta}
• GANANCIA NETA PARA SMARTQUOTE: ${budgetCurrency} ${computedTotals.gananciaNetaTotal} (Rentabilidad real: ${computedTotals.margenRealPct}%)

* ${budgetNotes}
    `.trim();

    navigator.clipboard.writeText(formattedText);
    setCopiedTextType('quote');
    setTimeout(() => setCopiedTextType(null), 3000);
  };

  const handleCopyText = (textToCopy: string, type: string) => {
    navigator.clipboard.writeText(textToCopy);
    setCopiedTextType(type);
    setTimeout(() => setCopiedTextType(null), 3000);
  };

  return (
    <div className="bg-slate-900 min-h-screen text-slate-100 font-sans" id="smart-quote-root">
      
      {/* SECCIÓN NAVBAR DE ALTA CATEGORÍA */}
      <nav className="bg-slate-950 border-b border-indigo-950/70 sticky top-0 z-40 navbar-container" id="nav-container">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="bg-indigo-600 p-2 rounded-xl text-white shadow-lg shadow-indigo-600/20">
              <Scale className="h-5.5 w-5.5" />
            </div>
            <div>
              <span className="font-extrabold tracking-tight text-lg bg-gradient-to-r from-indigo-200 via-indigo-50 to-white bg-clip-text text-transparent">SmartQuote</span>
              <span className="ml-2 text-[10px] font-bold px-2 py-0.5 bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 rounded-full uppercase">
                Panel Interno de Control
              </span>
            </div>
          </div>

          {/* Estado de Acceso Integrado por Tenant */}
          <div className="flex items-center gap-3 bg-slate-900 border border-slate-800 p-1.5 px-3 rounded-xl text-xs">
            <span className="text-slate-400">Workspace Activo:</span>
            <span className="font-semibold text-indigo-400 font-mono tracking-wider">{currentTenant.name}</span>
            <span className="text-[10px] bg-slate-800 text-slate-400 px-1.5 py-0.5 rounded uppercase font-bold">{currentTenant.type}</span>
          </div>

          <div className="flex gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800">
            <button 
              onClick={() => setActiveTab('calculator')}
              className={`py-1.5 px-3.5 rounded-lg text-xs font-semibold cursor-pointer transition ${activeTab === 'calculator' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'}`}
            >
              Carga e ítems
            </button>
            <button 
              onClick={() => setActiveTab('schema')}
              className={`py-1.5 px-3.5 rounded-lg text-xs font-semibold cursor-pointer transition ${activeTab === 'schema' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'}`}
            >
              Modelado DB (Prisma)
            </button>
            <button 
              onClick={() => setActiveTab('architecture')}
              className={`py-1.5 px-3.5 rounded-lg text-xs font-semibold cursor-pointer transition ${activeTab === 'architecture' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'}`}
            >
              Reporte de Ingeniería
            </button>
          </div>
        </div>
      </nav>

      {/* RECEPTOR DE INFORMACIÓN SUPERIOR */}
      <div className="bg-slate-950/40 border-b border-indigo-950/20 py-4" id="header-context">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          <div>
            <span className="text-slate-500 block mb-1">PROYECTO BAJO ANÁLISIS:</span>
            <input 
              type="text" 
              value={budgetTitle} 
              onChange={(e) => setBudgetTitle(e.target.value)}
              className="bg-transparent text-slate-200 font-bold border-b border-slate-800 hover:border-slate-700 focus:border-indigo-500 focus:bg-slate-900 outline-none w-full px-1 py-0.5"
            />
          </div>
          <div>
            <span className="text-slate-500 block mb-1">CÓDIGO DE CONTROL & MONEDA:</span>
            <div className="flex gap-2">
              <input 
                type="text" 
                value={budgetCode} 
                onChange={(e) => setBudgetCode(e.target.value)}
                className="bg-transparent text-slate-200 font-bold border-b border-slate-800 hover:border-slate-700 outline-none w-3/5 px-1 py-0.5 text-indigo-300 font-mono"
              />
              <select
                value={budgetCurrency}
                onChange={(e) => setBudgetCurrency(e.target.value)}
                className="bg-slate-900 text-slate-200 border border-slate-800 rounded px-1.5 py-0.5 outline-none text-xs"
              >
                <option value="USD">USD ($)</option>
                <option value="ARS">ARS ($Ar)</option>
                <option value="EUR">EUR (€)</option>
              </select>
            </div>
          </div>
          <div>
            <span className="text-slate-500 block mb-1">CLIENTE DESTINATARIO:</span>
            <select
              value={selectedClientId}
              onChange={(e) => setSelectedClientId(e.target.value)}
              className="bg-transparent text-indigo-400 font-semibold focus:bg-slate-900 outline-none w-full border-b border-slate-800 cursor-pointer"
            >
              {DEFAULT_CLIENTS.map(c => (
                <option key={c.id} value={c.id} className="bg-slate-900 text-slate-100">
                  {c.companyName} ({c.name})
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* CONTENIDO DE TABS */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6" id="main-content">
        
        {/* VISTA 1: CALCULADORA COMERCIAL */}
        {activeTab === 'calculator' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start" id="calculator-view">
            
            {/* COLUMNA IZQUIERDA: FORMULARIO DE CARGA + GRId ITEMS (8/12) */}
            <div className="lg:col-span-8 space-y-6">
              
              {/* COMPONENTE: FORMULARIO DE CARGA DE ÍTEMS */}
              <div className="bg-slate-950/70 border border-slate-800 rounded-2xl p-5 shadow-xl" id="creation-form">
                <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-800">
                  <div className="flex items-center gap-2">
                    <div className="bg-indigo-600/20 p-1.5 rounded-lg text-indigo-400">
                      <Plus className="h-4.5 w-4.5" />
                    </div>
                    <h2 className="font-extrabold text-sm tracking-tight uppercase text-slate-200">Formulario de Carga de Ítems</h2>
                  </div>
                  
                  {/* Presets rpidos */}
                  <div className="flex items-center gap-1.5">
                    <span className="text-[10px] text-slate-500 uppercase font-bold mr-1">Rápido:</span>
                    <button 
                      type="button" 
                      onClick={() => handleSetPresetItem('consultoria')} 
                      className="bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/20 text-amber-300 text-[10px] font-bold py-1 px-2 rounded-lg cursor-pointer transition"
                    >
                      HH Consultoría
                    </button>
                    <button 
                      type="button" 
                      onClick={() => handleSetPresetItem('servidores')} 
                      className="bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/20 text-emerald-300 text-[10px] font-bold py-1 px-2 rounded-lg cursor-pointer transition"
                    >
                      Insumo Cloud
                    </button>
                    <button 
                      type="button" 
                      onClick={() => handleSetPresetItem('licencias')} 
                      className="bg-sky-500/10 hover:bg-sky-500/20 border border-sky-500/20 text-sky-300 text-[10px] font-bold py-1 px-2 rounded-lg cursor-pointer transition"
                    >
                      Servicio Cerrado
                    </button>
                  </div>
                </div>

                <form onSubmit={handleFormAddItem} className="space-y-4">
                  {/* Nombre y Tipo de Rubro */}
                  <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
                    <div className="md:col-span-8">
                      <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Concepto o Tarea</label>
                      <input 
                        type="text" 
                        value={itemName}
                        onChange={(e) => setItemName(e.target.value)}
                        placeholder="Ej: Desarrollo de Endpoint de cobro con Stripe integration"
                        required
                        className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-slate-100 placeholder-slate-500 focus:border-indigo-500/80 focus:outline-none focus:bg-slate-900/90 transition-all font-medium"
                      />
                    </div>
                    <div className="md:col-span-4">
                      <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Estructura Rubro</label>
                      <div className="grid grid-cols-3 gap-1 bg-slate-900 p-1 border border-slate-800 rounded-xl">
                        <button
                          type="button"
                          onClick={() => setItemType('HOURLY')}
                          className={`py-1 rounded-lg text-[10px] font-extrabold transition-all cursor-pointer ${itemType === 'HOURLY' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'}`}
                        >
                          Horas
                        </button>
                        <button
                          type="button"
                          onClick={() => setItemType('MATERIAL')}
                          className={`py-1 rounded-lg text-[10px] font-extrabold transition-all cursor-pointer ${itemType === 'MATERIAL' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'}`}
                        >
                          Insumos
                        </button>
                        <button
                          type="button"
                          onClick={() => setItemType('FIXED')}
                          className={`py-1 rounded-lg text-[10px] font-extrabold transition-all cursor-pointer ${itemType === 'FIXED' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-slate-200'}`}
                        >
                          Fijo
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Detalle Variable de acuerdo al Rubro */}
                  <div className="bg-slate-900/50 border border-slate-800/80 p-4 rounded-xl">
                    <h4 className="text-[10px] tracking-wider font-extrabold text-indigo-400 uppercase mb-3 flex items-center gap-1.5">
                      {itemType === 'HOURLY' && <><Clock className="h-3.5 w-3.5" /> Configuración de Tarifa por Hora (Costo Variable)</>}
                      {itemType === 'MATERIAL' && <><HardDrive className="h-3.5 w-3.5" /> Parámetros para Materiales / Revendedora de Servicios</>}
                      {itemType === 'FIXED' && <><Briefcase className="h-3.5 w-3.5" /> Precio Cerrado / Proyecto Llave en Mano</>}
                    </h4>

                    {itemType === 'HOURLY' && (
                      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
                        <div>
                          <label className="block text-slate-500 mb-1">Costo por Hora ({budgetCurrency})</label>
                          <input 
                            type="number"
                            value={hourlyRate}
                            onChange={(e) => setHourlyRate(Math.max(0, Number(e.target.value)))}
                            className="bg-slate-950 border border-slate-800 rounded-lg p-2 font-mono font-bold text-indigo-300 w-full"
                          />
                        </div>
                        <div>
                          <label className="block text-slate-500 mb-1">Cantidad de Horas</label>
                          <input 
                            type="number"
                            value={hoursCount}
                            onChange={(e) => setHoursCount(Math.max(1, Number(e.target.value)))}
                            className="bg-slate-950 border border-slate-800 rounded-lg p-2 font-mono font-bold text-slate-200 w-full"
                          />
                        </div>
                        <div className="flex flex-col justify-center bg-slate-950/60 p-2.5 rounded-lg border border-slate-800/50">
                          <span className="text-[10px] text-slate-400">COSTO BASE PARCIAL:</span>
                          <span className="font-mono font-extrabold text-sm text-emerald-400">
                            {budgetCurrency} {roundToTwoDecimals(hourlyRate * hoursCount)}
                          </span>
                        </div>
                      </div>
                    )}

                    {itemType === 'MATERIAL' && (
                      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 text-xs">
                        <div>
                          <label className="block text-slate-500 mb-1">Costo Unitario ({budgetCurrency})</label>
                          <input 
                            type="number"
                            value={materialUnitCost}
                            onChange={(e) => setMaterialUnitCost(Math.max(0, Number(e.target.value)))}
                            className="bg-slate-950 border border-slate-800 rounded-lg p-2 font-mono font-bold text-indigo-300 w-full"
                          />
                        </div>
                        <div>
                          <label className="block text-slate-500 mb-1">Cantidad</label>
                          <input 
                            type="number"
                            value={materialQuantity}
                            onChange={(e) => setMaterialQuantity(Math.max(1, Number(e.target.value)))}
                            className="bg-slate-950 border border-slate-800 rounded-lg p-2 font-mono font-bold text-slate-200 w-full"
                          />
                        </div>
                        <div>
                          <label className="block text-slate-500 mb-1">Unidad Medida</label>
                          <input 
                            type="text"
                            value={materialLabel}
                            onChange={(e) => setMaterialLabel(e.target.value)}
                            placeholder="meses, licencias"
                            className="bg-slate-950 border border-slate-800 rounded-lg p-2 text-slate-200 w-full"
                          />
                        </div>
                        <div className="flex flex-col justify-center bg-slate-950/60 p-2.5 rounded-lg border border-slate-800/50">
                          <span className="text-[10px] text-slate-400">COSTO MATERIALES:</span>
                          <span className="font-mono font-extrabold text-sm text-emerald-400">
                            {budgetCurrency} {roundToTwoDecimals(materialUnitCost * materialQuantity)}
                          </span>
                        </div>
                      </div>
                    )}

                    {itemType === 'FIXED' && (
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                        <div>
                          <label className="block text-slate-500 mb-1">Costo Fijo Equivalente de Proveedor ({budgetCurrency})</label>
                          <input 
                            type="number"
                            value={fixedServiceCost}
                            onChange={(e) => setFixedServiceCost(Math.max(0, Number(e.target.value)))}
                            className="bg-slate-950 border border-slate-800 rounded-lg p-2 font-mono font-bold text-indigo-300 w-full"
                          />
                        </div>
                        <div className="flex flex-col justify-center bg-slate-950/60 p-2.5 rounded-lg border border-slate-800/50">
                          <span className="text-[10px] text-slate-400">COSTO GLOBAL ACORDADO:</span>
                          <span className="font-mono font-extrabold text-sm text-emerald-400">
                            {budgetCurrency} {roundToTwoDecimals(fixedServiceCost)}
                          </span>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Configuración Financiera Individual Aislada por Item */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                    
                    {/* Margen de Ganancia */}
                    <div>
                      <div className="flex justify-between items-center mb-1">
                        <label className="text-[10px] font-bold text-slate-400 uppercase">Margen Ganancia</label>
                        <span className="font-bold text-indigo-400">{profitMargin}%</span>
                      </div>
                      <input 
                        type="range" 
                        min="0" 
                        max="200" 
                        step="5"
                        value={profitMargin}
                        onChange={(e) => setProfitMargin(Number(e.target.value))}
                        className="w-full accent-indigo-500 h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer"
                      />
                      <p className="text-[9px] text-slate-500 mt-0.5">Incremento sobre el precio de costo base.</p>
                    </div>

                    {/* Descuento por ítem */}
                    <div>
                      <div className="flex justify-between items-center mb-1">
                        <label className="text-[10px] font-bold text-slate-400 uppercase">Dcto. Específico Ítem</label>
                        <span className="font-bold text-rose-400">{itemDiscount}%</span>
                      </div>
                      <input 
                        type="range" 
                        min="0" 
                        max="50" 
                        step="1"
                        value={itemDiscount}
                        onChange={(e) => setItemDiscount(Number(e.target.value))}
                        className="w-full accent-rose-500 h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer"
                      />
                      <p className="text-[9px] text-slate-500 mt-0.5">Bonificación aplicada previo a impuestos.</p>
                    </div>

                    {/* Impuesto IVA */}
                    <div>
                      <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1.5">Alícuota impositiva (IVA)</label>
                      <select
                        value={ivaRate}
                        onChange={(e) => setIvaRate(Number(e.target.value))}
                        className="w-full bg-slate-900 border border-slate-800 rounded-xl px-2.5 py-2 text-slate-300 font-semibold focus:outline-none"
                      >
                        {IVA_OPTIONS.map(o => (
                          <option key={o.value} value={o.value} className="bg-slate-950 text-slate-200">{o.label}</option>
                        ))}
                      </select>
                    </div>

                  </div>

                  {/* Acciones del formulario */}
                  <div className="flex justify-between items-center pt-3 border-t border-slate-800/60">
                    <div className="text-[10px] text-slate-400">
                      <strong className="text-yellow-500">Nota:</strong> Se creará un registro aislado con cálculo unitario auditado.
                    </div>
                    <button 
                      type="submit" 
                      className="bg-indigo-600 hover:bg-indigo-500 text-white font-bold py-2.5 px-6 rounded-xl text-xs transition-all shadow-lg hover:shadow-indigo-600/20 active:translate-y-0.5 cursor-pointer flex items-center gap-2"
                    >
                      <Plus className="h-4 w-4" />
                      Inyectar Ítem Comercial
                    </button>
                  </div>
                </form>
              </div>

              {/* GRILLA INTERACTIVA DE ÍTEMS EN TIEMPO REAL */}
              <div className="bg-slate-950/70 border border-slate-800 rounded-2xl p-5 shadow-xl" id="items-grid-container">
                <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-800">
                  <div className="flex items-center gap-2">
                    <FileSpreadsheet className="h-4.5 w-4.5 text-indigo-400" />
                    <h3 className="font-extrabold text-sm tracking-tight uppercase text-slate-200">Ítems Cotizados actualmente ({items.length})</h3>
                  </div>
                  <button 
                    onClick={() => {
                      setItems([]);
                      setGlobalDiscount(0);
                    }}
                    className="text-xs text-slate-400 hover:text-rose-400 font-medium px-2.5 py-1 hover:bg-rose-500/10 rounded-lg transition cursor-pointer"
                  >
                    Vaciar todo el detalle
                  </button>
                </div>

                {items.length === 0 ? (
                  <div className="py-12 text-center text-slate-500 border-2 border-dashed border-slate-800 rounded-xl" id="empty-state">
                    <Calculator className="h-10 w-10 text-slate-600 mx-auto mb-3" />
                    <p className="text-xs font-semibold text-slate-400">No hay servicios ni productos cotizados</p>
                    <p className="text-[11px] text-slate-500 mt-1 max-w-sm mx-auto">Use de manera lúdica el cargador de arriba o clickee los presets preconfigurados para inyectar modelos de alta fidelidad.</p>
                  </div>
                ) : (
                  <div className="space-y-4" id="items-list">
                    {items.map((it) => {
                      // Desglose visual individual con soporte reactivo inmediato
                      const itemCostoDefCheck = Number(it.costoBase || 0);
                      const itemMargenDef = Number(it.margenGanancia || 0);
                      const itemDescuentoPct = Number(it.descuento || 0);
                      
                      const itemPrecioSugerido = itemCostoDefCheck * (1 + (itemMargenDef / 100));
                      const itemMontoDescuento = itemPrecioSugerido * (itemDescuentoPct / 100);
                      const itemSubtotalConDescuento = itemPrecioSugerido - itemMontoDescuento;
                      const itemIvaMont = itemSubtotalConDescuento * (Number(it.alicuotaIva || 0) / 100);
                      const itemPrecioFinalTotal = itemSubtotalConDescuento + itemIvaMont;

                      return (
                        <div 
                          key={it.id} 
                          className="bg-slate-900 border border-slate-800 rounded-xl p-4 relative group hover:border-indigo-950/80 transition-all font-mono text-xs"
                        >
                          <button
                            onClick={() => handleDeleteItem(it.id!)}
                            className="absolute top-2.5 right-2.5 p-1 text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 rounded transition cursor-pointer"
                            title="Quitar ítem"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                          </button>

                          <div className="flex flex-col md:flex-row md:items-center justify-between gap-y-2 mb-3">
                            <div className="flex items-start gap-2 max-w-md">
                              {/* Insignia del Rubro */}
                              {it.type === 'HOURLY' && (
                                <span className="bg-amber-500/10 text-amber-300 border border-amber-500/20 text-[9px] font-bold px-1.5 py-0.5 rounded uppercase mt-0.5" title="Rubro basado en Horas">
                                  H/H
                                </span>
                              )}
                              {it.type === 'MATERIAL' && (
                                <span className="bg-emerald-500/10 text-emerald-300 border border-emerald-500/20 text-[9px] font-bold px-1.5 py-0.5 rounded uppercase mt-0.5" title="Insumos / Materiales">
                                  Insumo
                                </span>
                              )}
                              {it.type === 'FIXED' && (
                                <span className="bg-sky-500/10 text-sky-300 border border-sky-500/20 text-[9px] font-bold px-1.5 py-0.5 rounded uppercase mt-0.5" title="Precio Fijo">
                                  Fijo
                                </span>
                              )}
                              <div>
                                <input 
                                  type="text"
                                  value={it.name}
                                  onChange={(e) => handleQuickUpdateItem(it.id!, 'name', e.target.value)}
                                  className="font-bold text-slate-100 bg-transparent border-b border-transparent focus:border-slate-700 hover:border-slate-800 outline-none w-72 md:w-96 text-xs text-ellipsis overflow-hidden whitespace-nowrap"
                                />
                              </div>
                            </div>
                          </div>

                          {/* Inputs rápidos editables inline para auditar en vivo */}
                          <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 pt-2.5 border-t border-slate-950/70 text-slate-400">
                            
                            {/* Costo del rubro */}
                            {it.type === 'HOURLY' && (
                              <>
                                <div>
                                  <span className="block text-[8px] text-slate-500 font-bold uppercase mb-0.5">U$ Cost.H</span>
                                  <input 
                                    type="number"
                                    value={it.hourlyRate || 0}
                                    onChange={(e) => handleQuickUpdateItem(it.id!, 'hourlyRate', e.target.value)}
                                    className="bg-slate-950 border border-slate-800 rounded px-1.5 py-0.5 font-bold text-slate-200 w-full text-[11px]"
                                  />
                                </div>
                                <div>
                                  <span className="block text-[8px] text-slate-500 font-bold uppercase mb-0.5">Horas</span>
                                  <input 
                                    type="number"
                                    value={it.hours || 0}
                                    onChange={(e) => handleQuickUpdateItem(it.id!, 'hours', e.target.value)}
                                    className="bg-slate-950 border border-slate-800 rounded px-1.5 py-0.5 font-bold text-slate-200 w-full text-[11px]"
                                  />
                                </div>
                              </>
                            )}

                            {it.type === 'MATERIAL' && (
                              <>
                                <div>
                                  <span className="block text-[8px] text-slate-500 font-bold uppercase mb-0.5">U$ Cost.Unit</span>
                                  <input 
                                    type="number"
                                    value={it.unitCost || 0}
                                    onChange={(e) => handleQuickUpdateItem(it.id!, 'unitCost', e.target.value)}
                                    className="bg-slate-950 border border-slate-800 rounded px-1.5 py-0.5 font-bold text-slate-200 w-full text-[11px]"
                                  />
                                </div>
                                <div>
                                  <span className="block text-[8px] text-slate-500 font-bold uppercase mb-0.5">Cantidad</span>
                                  <input 
                                    type="number"
                                    value={it.quantity || 0}
                                    onChange={(e) => handleQuickUpdateItem(it.id!, 'quantity', e.target.value)}
                                    className="bg-slate-950 border border-slate-800 rounded px-1.5 py-0.5 font-bold text-slate-200 w-full text-[11px]"
                                  />
                                </div>
                              </>
                            )}

                            {it.type === 'FIXED' && (
                              <div className="col-span-2">
                                <span className="block text-[8px] text-slate-500 font-bold uppercase mb-0.5">U$ Cost.Fijo</span>
                                <input 
                                  type="number"
                                  value={it.fixedCost || 0}
                                  onChange={(e) => handleQuickUpdateItem(it.id!, 'fixedCost', e.target.value)}
                                  className="bg-slate-950 border border-slate-800 rounded px-1.5 py-0.5 font-bold text-indigo-300 w-full text-[11px]"
                                />
                              </div>
                            )}

                            {/* Margen */}
                            <div>
                              <span className="block text-[8px] text-slate-500 font-bold uppercase mb-0.5">Margen %</span>
                              <input 
                                type="number"
                                value={it.margenGanancia}
                                onChange={(e) => handleQuickUpdateItem(it.id!, 'margenGanancia', e.target.value)}
                                className="bg-slate-950 border border-slate-800 rounded px-1.5 py-0.5 font-bold text-slate-200 w-full text-[11px]"
                              />
                            </div>

                            {/* Descuento */}
                            <div>
                              <span className="block text-[8px] text-slate-500 font-bold uppercase mb-0.5">Dcto. Item %</span>
                              <input 
                                type="number"
                                value={it.descuento}
                                onChange={(e) => handleQuickUpdateItem(it.id!, 'descuento', e.target.value)}
                                className="bg-slate-950 border border-slate-800 rounded px-1.5 py-0.5 font-bold text-rose-400 w-full text-[11px]"
                              />
                            </div>

                            {/* IVA */}
                            <div>
                              <span className="block text-[8px] text-slate-500 font-bold uppercase mb-0.5">Tasa IVA %</span>
                              <select
                                value={it.alicuotaIva}
                                onChange={(e) => handleQuickUpdateItem(it.id!, 'alicuotaIva', Number(e.target.value))}
                                className="bg-slate-950 border border-slate-800 rounded px-1 py-0.5 font-bold text-slate-300 w-full text-[11px]"
                              >
                                <option value={21.0}>21%</option>
                                <option value={10.5}>10.5%</option>
                                <option value={27.0}>27%</option>
                                <option value={0.0}>0%</option>
                              </select>
                            </div>

                          </div>

                          {/* Detalles del consolidado por item post-cómputo */}
                          <div className="mt-3.5 pt-2 border-t border-slate-950/40 flex flex-wrap gap-x-5 gap-y-1 text-[10px] text-slate-500 justify-between">
                            <div>
                              Costo Base: <span className="text-slate-300 font-bold">{budgetCurrency} {roundToTwoDecimals(itemCostoDefCheck)}</span>
                            </div>
                            <div>
                              Utilidad: <span className="text-emerald-400 font-bold">+{budgetCurrency} {roundToTwoDecimals(itemPrecioSugerido - itemCostoDefCheck)}</span>
                            </div>
                            {itemDescuentoPct > 0 && (
                              <div className="text-rose-400">
                                Descuento: <span>-{budgetCurrency} {roundToTwoDecimals(itemMontoDescuento)}</span>
                              </div>
                            )}
                            <div>
                              Venta Neta: <span className="text-indigo-300 font-bold">{budgetCurrency} {roundToTwoDecimals(itemSubtotalConDescuento)}</span>
                            </div>
                            <div>
                              IVA ({it.alicuotaIva}%): <span className="text-slate-400">{budgetCurrency} {roundToTwoDecimals(itemIvaMont)}</span>
                            </div>
                            <div className="text-indigo-200">
                              Precio Final: <span className="font-extrabold text-indigo-400">{budgetCurrency} {roundToTwoDecimals(itemPrecioFinalTotal)}</span>
                            </div>
                          </div>

                        </div>
                      );
                    })}
                  </div>
                )}
              </div>

            </div>

            {/* COLUMNA DERECHA: DASHBOARD DE RENTABILIDAD FIJO/ADHERIDO (4/12) */}
            <div className="lg:col-span-4 lg:sticky lg:top-20 space-y-6" id="dashboard-sidebar">
              
              {/* COMPONENTE: PANEL DE SINCRONIZACIÓN CLOUD CON FIRESTORE */}
              <FirebaseSyncPanel 
                budgetTitle={budgetTitle}
                setBudgetTitle={setBudgetTitle}
                budgetCode={budgetCode}
                setBudgetCode={setBudgetCode}
                budgetCurrency={budgetCurrency}
                setBudgetCurrency={setBudgetCurrency}
                budgetNotes={budgetNotes}
                setBudgetNotes={setBudgetNotes}
                globalDiscount={globalDiscount}
                setGlobalDiscount={setGlobalDiscount}
                items={items}
                setItems={setItems}
                selectedTenantId={selectedTenantId}
                setSelectedTenantId={setSelectedTenantId}
                selectedClientId={selectedClientId}
                setSelectedClientId={setSelectedClientId}
              />
              
              {/* COMPONENTE PRINCIPAL: RENTABILIDAD EN TIEMPO REAL */}
              <div className="bg-slate-950 border border-indigo-950 rounded-2xl p-6 shadow-2xl relative overflow-hidden">
                <div className="absolute top-0 right-0 p-4 opacity-5 pointer-events-none">
                  <TrendingUp className="h-32 w-32 text-indigo-500" />
                </div>

                <div className="relative z-10 space-y-5">
                  <div className="flex items-center gap-2 mb-2">
                    <TrendingUp className="h-4.5 w-4.5 text-emerald-400" />
                    <h3 className="font-extrabold text-xs tracking-wider uppercase text-slate-400">Rentabilidad en Tiempo Real</h3>
                  </div>

                  {/* CONTADOR ENORME: GANANCIA NETA */}
                  <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex flex-col justify-between relative overflow-hidden">
                    <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Ganancia Neta Realizada</span>
                    
                    <div className="mt-2 flex items-baseline gap-2.5">
                      <span className={`text-2xl md:text-3.5xl font-extrabold font-mono tracking-tight ${computedTotals.gananciaNetaTotal >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                        {budgetCurrency} {computedTotals.gananciaNetaTotal.toLocaleString()}
                      </span>
                      {computedTotals.gananciaNetaTotal >= 0 ? (
                        <span className="text-[10px] font-bold px-1.5 py-0.5 bg-emerald-500/10 text-emerald-400 rounded">Rentable</span>
                      ) : (
                        <span className="text-[10px] font-bold px-1.5 py-0.5 bg-rose-500/10 text-rose-400 rounded">Pérdida</span>
                      )}
                    </div>
                    
                    <div className="mt-2 flex justify-between items-center text-[11px] text-slate-400 pt-1 border-t border-slate-950/50">
                      <span>Rentabilidad real efectuada:</span>
                      <strong className="text-slate-200 font-mono">{computedTotals.margenRealPct}%</strong>
                    </div>
                  </div>

                  {/* BARRA DE COSTO TOTAL */}
                  <div className="grid grid-cols-2 gap-3 text-xs">
                    <div className="p-3 bg-slate-900/60 border border-indigo-950/30 rounded-xl">
                      <span className="text-slate-500 block text-[9px] uppercase font-bold">Costos Totales</span>
                      <span className="text-base font-extrabold font-mono text-slate-300 mt-1 block">
                        {budgetCurrency} {computedTotals.costoTotal.toLocaleString()}
                      </span>
                    </div>

                    <div className="p-3 bg-slate-900/60 border border-indigo-950/30 rounded-xl">
                      <span className="text-slate-500 block text-[9px] uppercase font-bold">Venta Neta (Subtotal)</span>
                      <span className="text-base font-extrabold font-mono text-indigo-300 mt-1 block">
                        {budgetCurrency} {computedTotals.subtotalVentaTotal.toLocaleString()}
                      </span>
                    </div>
                  </div>

                  {/* SLIDER DE DESCUENTO GLOBAL */}
                  <div className="p-4 bg-slate-900/40 rounded-xl border border-slate-800/80">
                    <div className="flex justify-between items-center mb-1.5 text-xs">
                      <label className="text-[10px] font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1">
                        <Percent className="h-3.5 w-3.5 text-indigo-400" />
                        Descuento Global Aplicado
                      </label>
                      <span className="px-2 py-0.5 rounded-lg text-xs font-bold text-rose-400 bg-rose-500/10 font-mono">
                        {globalDiscount}%
                      </span>
                    </div>

                    <input 
                      type="range"
                      min="0"
                      max="50"
                      step="5"
                      value={globalDiscount}
                      onChange={(e) => setGlobalDiscount(Number(e.target.value))}
                      className="w-full accent-indigo-500 h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer"
                    />

                    <div className="flex justify-between text-[9px] text-slate-500 mt-1">
                      <span>0%</span>
                      <span>15%</span>
                      <span>30%</span>
                      <span>50% Max</span>
                    </div>
                    <p className="text-[9px] text-slate-400 mt-2 leading-relaxed">
                      Este descuento se computa sobre el subtotal de venta e impacta instantáneamente la base imponible y ganancia final.
                    </p>
                  </div>

                  {/* DESGLOSE IVA Y PRECIO FINAL DE VENTA */}
                  <div className="space-y-1.5 pt-3 border-t border-slate-800">
                    <div className="flex justify-between text-xs text-slate-400">
                      <span>Suma Total IVA calculado:</span>
                      <span className="font-mono">{budgetCurrency} {computedTotals.ivaTotalMasivo}</span>
                    </div>

                    <div className="flex justify-between text-xs text-slate-400">
                      <span>Workspace Multi-Tenant:</span>
                      <span className="text-indigo-400 font-bold">{currentTenant.name}</span>
                    </div>

                    <div className="p-3.5 rounded-xl bg-indigo-950/40 border border-indigo-900/50 mt-3">
                      <span className="text-indigo-300 block text-[9px] uppercase font-extrabold tracking-widest">PRECIO FINAL DE VENTA (IVA INC.)</span>
                      <span className="text-2xl font-black font-mono text-white tracking-tight mt-1.5 block">
                        {budgetCurrency} {computedTotals.precioFinalVenta.toLocaleString()}
                      </span>
                    </div>
                  </div>

                  {/* BOTONES DE CONTROL DE PRESUPUESTOS */}
                  <div className="grid grid-cols-1 gap-2 pt-2">
                    <button 
                      onClick={() => setIsMarginModalOpen(true)}
                      className="w-full py-3 px-4 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold transition-all shadow-lg shadow-indigo-600/10 cursor-pointer flex items-center justify-center gap-2"
                      id="btn-analyze-margin"
                    >
                      <Scale className="h-4 w-4" />
                      Analizar Margen de Rentabilidad
                    </button>
                    
                    <button 
                      onClick={handleCopyFormattedQuote}
                      className="w-full py-2 px-4 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-200 rounded-xl text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-2"
                      id="btn-copy-quote"
                    >
                      <Copy className="h-4 w-4 text-slate-400" />
                      {copiedTextType === 'quote' ? '✓ Copiado en Portapapeles!' : 'Copiar Reporte Comercial'}
                    </button>
                  </div>

                  {/* INFORMACIÓN DEL CLIENTE RECEPTOR */}
                  <div className="p-3 rounded-lg bg-slate-900/30 border border-slate-800/80 text-[11px] text-slate-400 line-clamp-3">
                    <strong className="text-slate-300 block mb-1">Destinatario Factura:</strong>
                    Razón Social: <span className="text-slate-200 font-semibold">{currentClient.companyName}</span> <br/>
                    Identificador Fiscal: <span className="text-slate-200 font-mono">{currentClient.taxId || 'Sin registrar'}</span> <br/>
                    Email: <span className="text-indigo-400">{currentClient.email}</span>
                  </div>

                </div>
              </div>

            </div>

          </div>
        )}

        {/* VISTA 2: DIAGRAMA DE BASE DE DATOS (PRISMA Y SQL) */}
        {activeTab === 'schema' && (
          <div className="space-y-6" id="schema-view">
            <div className="bg-slate-950/70 border border-slate-800 rounded-2xl p-6 shadow-xl">
              <div className="flex items-center justify-between mb-4 pb-3 border-b border-slate-800">
                <div className="flex items-center gap-2">
                  <Database className="h-5 w-5 text-indigo-400" />
                  <div>
                    <h2 className="font-extrabold text-base text-slate-200">Definición de Esquema de Base de Datos</h2>
                    <p className="text-xs text-slate-400">PostgreSQL Relacional con Prisma ORM</p>
                  </div>
                </div>
                
                <div className="flex gap-2">
                  <button 
                    onClick={() => handleCopyText('schema.prisma', 'prisma')}
                    className="py-1 px-3 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 rounded-lg text-xs font-semibold cursor-pointer transition"
                  >
                    {copiedTextType === 'prisma' ? '✓ Copiado!' : 'Copiar Prisma'}
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
                
                {/* Panel de descripcin de aislamiento */}
                <div className="lg:col-span-1 space-y-4 text-xs">
                  <div className="p-4 bg-slate-900 rounded-xl border border-slate-800">
                    <h4 className="font-bold text-indigo-400 mb-2 uppercase text-[10px]">Estructura de Multi-tenant</h4>
                    <p className="text-slate-300 leading-relaxed">
                      El modelo de aislamiento se fundamenta en la tabla <code className="text-indigo-300 font-mono">tenants</code>. 
                      Todos los datos críticos (<code className="font-mono text-slate-300">users</code>, <code className="font-mono text-slate-300">clients</code>, <code className="font-mono text-slate-300">budgets</code>) se encuentran segregados con FK directa indexados.
                    </p>
                  </div>

                  <div className="p-4 bg-slate-900 rounded-xl border border-slate-800">
                    <h4 className="font-bold text-amber-400 mb-2 uppercase text-[10px]">Tablas de Negocio</h4>
                    <ul className="space-y-1.5 text-slate-300">
                      <li>• <strong>Tenants</strong>: Freelancers o Empresas.</li>
                      <li>• <strong>Users</strong>: Acceso por rol (ADMIN, VENDEDOR).</li>
                      <li>• <strong>Clients</strong>: Razón Social y CUIT.</li>
                      <li>• <strong>Budgets</strong>: Cabecera con totales calculados persistidos en base de datos.</li>
                      <li>• <strong>BudgetItems</strong>: Costos, margen, IVA y tipo por rubro.</li>
                    </ul>
                  </div>

                  <div className="p-4 bg-slate-900 rounded-xl border border-slate-800">
                    <h4 className="font-bold text-emerald-400 mb-2 uppercase text-[10px]">Campos de Rubros</h4>
                    <p className="text-slate-300 leading-relaxed">
                      Los campos <code className="text-slate-300 font-mono">hourlyRate</code>, <code className="text-slate-300 font-mono">hours</code>, <code className="text-slate-300 font-mono">unitCost</code>, y <code className="text-slate-300 font-mono font-bold">fixedCost</code> son nulables, adaptándose reactivamente según la bandera enum de rubro del ítem.
                    </p>
                  </div>
                </div>

                {/* Bloque de cdigo schema.prisma */}
                <div className="lg:col-span-3">
                  <div className="bg-slate-950 p-4 rounded-xl border border-slate-800 max-h-[600px] overflow-y-auto">
                    <pre className="text-[11px] font-mono text-indigo-200 leading-relaxed">
{`// /src/db/schema.prisma

datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
}

generator client {
  provider = "prisma-client-js"
}

enum TenantType {
  FREELANCER
  COMPANY
}

enum UserRole {
  ADMIN
  VENDEDOR
}

enum BudgetStatus {
  BORRADOR
  ENVIADO
  ACEPTADO
  RECHAZADO
  VENCIDO
}

enum ItemType {
  HOURLY
  MATERIAL
  FIXED
}

model Tenant {
  id        String     @id @default(uuid())
  name      String     
  type      TenantType @default(FREELANCER)
  createdAt DateTime   @default(now())
  updatedAt DateTime   @updatedAt

  users     User[]
  clients   Client[]
  budgets   Budget[]

  @@map("tenants")
}

model User {
  id           String     @id @default(uuid())
  email        String     @unique
  passwordHash String
  name         String
  role         UserRole   @default(ADMIN)
  isActive     Boolean    @default(true)
  tenantId     String
  createdAt    DateTime   @default(now())
  updatedAt    DateTime   @updatedAt

  tenant       Tenant     @relation(fields: [tenantId], references: [id], onDelete: Cascade)
  budgets      Budget[]

  @@index([tenantId])
  @@map("users")
}

model Client {
  id           String   @id @default(uuid())
  name         String   
  companyName  String?  
  email        String
  phone        String?
  taxId        String?  // CUIT / Identificación fiscal
  address      String?
  tenantId     String
  createdAt    DateTime @default(now())
  updatedAt    DateTime @updatedAt

  tenant       Tenant   @relation(fields: [tenantId], references: [id], onDelete: Cascade)
  budgets      Budget[]

  @@index([tenantId])
  @@map("clients")
}

model Budget {
  id                 String       @id @default(uuid())
  code               String       
  title              String       
  description        String?
  status             BudgetStatus @default(BORRADOR)
  currency           String       @default("ARS")
  exchangeRate       Decimal      @default(1.0)
  
  // Totales financieros cacheados en base de datos para alta velocidad
  costoTotal         Decimal      @default(0.0)   @db.Decimal(12, 2)
  subtotalVenta      Decimal      @default(0.0)   @db.Decimal(12, 2)
  ivaTotal           Decimal      @default(0.0)   @db.Decimal(12, 2)
  precioFinal        Decimal      @default(0.0)   @db.Decimal(12, 2)
  
  tenantId           String
  clientId           String
  userId             String       
  createdAt          DateTime     @default(now())
  updatedAt          DateTime     @updatedAt

  tenant             Tenant       @relation(fields: [tenantId], references: [id], onDelete: Cascade)
  client             Client       @relation(fields: [clientId], references: [id], onDelete: Restrict)
  creator            User         @relation(fields: [userId], references: [id], onDelete: Restrict)
  items              BudgetItem[]

  @@unique([tenantId, code])
  @@index([tenantId])
  @@index([clientId])
  @@map("budgets")
}

model BudgetItem {
  id             String   @id @default(uuid())
  budgetId       String
  name           String   
  description    String?  
  type           ItemType @default(FIXED)

  // --- Flexibilidad de Rubros ---
  hourlyRate     Decimal? @db.Decimal(10, 2)
  hours          Decimal? @db.Decimal(7, 2)
  
  unitCost       Decimal? @db.Decimal(12, 2)
  quantity       Decimal? @db.Decimal(10, 2)
  unitLabel      String?  @default("unidades")

  fixedCost      Decimal? @db.Decimal(12, 2)

  // --- Estructura Financiera Aislada ---
  costoBase      Decimal  @db.Decimal(12, 2)
  margenGanancia Decimal  @db.Decimal(5, 2)  
  alicuotaIva    Decimal  @db.Decimal(4, 2)  
  descuento      Decimal  @default(0.0)      @db.Decimal(5, 2)  

  // Valores calculados redundantes para rapidez en bsquedas directas
  subtotalVenta  Decimal  @db.Decimal(12, 2)
  montoIva       Decimal  @db.Decimal(12, 2)
  precioFinal    Decimal  @db.Decimal(12, 2)

  budget         Budget   @relation(fields: [budgetId], references: [id], onDelete: Cascade)

  @@index([budgetId])
  @@map("budget_items")
}`}
                    </pre>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* VISTA 3: REPORTE DE INGENIERÍA Y ARQUITECTURA */}
        {activeTab === 'architecture' && (
          <div className="space-y-6" id="architecture-view">
            <div className="bg-slate-950/70 border border-slate-800 rounded-2xl p-6 shadow-xl">
              <h2 className="text-lg font-extrabold text-indigo-300 mb-4 pb-2 border-b border-indigo-950/60 uppercase text-[13px] tracking-wider">
                Análisis Arquitectónico de Backend Senior: SmartQuote & CotizAR
              </h2>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs">
                
                {/* Col izquierda */}
                <div className="space-y-4">
                  <div className="bg-slate-900 p-4 rounded-xl border border-indigo-950/40">
                    <h3 className="font-bold text-slate-200 mb-2 flex items-center gap-2">
                      <ShieldCheck className="h-4 w-4 text-emerald-400" />
                      Aislamiento Seguro en Base de Datos (Multi-tenancy)
                    </h3>
                    <p className="text-slate-400 leading-relaxed">
                      El sistema utiliza un esquema relacional con un modelo de <strong>Multi-Tenant Lógico</strong>. 
                      Para asegurar que los vendedores de un Tenant no accedan a las cotizaciones de otro, cada consulta de lectura/escritura (en Prisma o SQL) 
                      debe incorporar preventivamente la constante del contexto de seguridad:
                    </p>
                    <pre className="mt-2 bg-slate-950 p-2 rounded font-mono text-[10.5px] text-indigo-300">
{`prisma.budget.findMany({
  where: { tenantId: userContext.tenantId }
})`}
                    </pre>
                    <p className="mt-2 text-slate-400">
                      Además, el índice compuesto de unicidad <code className="text-slate-300">uq_budgets_tenant_code</code> asegura que cada tenant
                      posea sus de códigos independientes secuenciales (Ej: COT-001) para mayor flexibilidad legal.
                    </p>
                  </div>

                  <div className="bg-slate-900 p-4 rounded-xl border border-indigo-950/40">
                    <h3 className="font-bold text-slate-200 mb-2 flex items-center gap-2">
                      <Scale className="h-4 w-4 text-indigo-400" />
                      Motor Matemático: Precisión Decimal frente a Float
                    </h3>
                    <p className="text-slate-400 leading-relaxed">
                      En sistemas de facturación y presupuestos, el uso de floats comunes (<code className="text-rose-400 font-mono">double</code> o tipo nativo JS/TS) genera problemas de redondeo IEEE 754 (Ej: 0.1 + 0.2 = 0.30000000000000004).
                    </p>
                    <ul className="mt-2 space-y-1.5 text-slate-300 ml-4 py-1.5 border-l-2 border-indigo-500 pl-3">
                      <li>• En Base de Datos: Especificamos <strong className="text-slate-100 font-mono">Decimal(12, 2)</strong> que almacena con precisión exacta los centavos, tolerando billones de divisa.</li>
                      <li>• En el Servidor TypeScript: El motor <code className="text-indigo-300 font-mono">calculateBudgetTotals</code> encapsula redondeos mitigando fluctuaciones decimales.</li>
                    </ul>
                  </div>
                </div>

                {/* Col derecha */}
                <div className="space-y-4">
                  <div className="bg-slate-900 p-4 rounded-xl border border-indigo-950/40">
                    <h3 className="font-bold text-slate-200 mb-2 flex items-center gap-2">
                      <Layers className="h-4 w-4 text-amber-400" />
                      Aislamiento Financiero por Ítem
                    </h3>
                    <p className="text-slate-400 leading-relaxed">
                      Cada ítem resguarda y consolida en su propia fila de base de datos la estructura de costos (Costo, Margen, IVA, Descuento) 
                      vigente al momento de agregarse. Ésto evita el típico bug de regresión donde cambiar dinámicamente un precio general en el inventario o la alícuota general de impuestos destruye el historial impositivo de cotizaciones enviadas al cliente hace meses.
                    </p>
                  </div>

                  <div className="bg-slate-900 p-4 rounded-xl border border-indigo-950/40">
                    <h3 className="font-bold text-slate-200 mb-2 flex items-center gap-2">
                      <Receipt className="h-4 w-4 text-indigo-400" />
                      Distribución por Alícuota (Fórmula Tributaria)
                    </h3>
                    <p className="text-slate-400 leading-relaxed">
                      La base imponible es agrupada matemáticamente por alícuotas del impuesto de manera que la devolución impositiva para la declaración contable sea inmediata:
                    </p>
                    <div className="mt-3 p-3 bg-slate-950 rounded border border-slate-800">
                      <span className="text-[10px] text-slate-500 block mb-1 uppercase font-bold text-slate-400">Distribución de IVA Activo para la simulación actual:</span>
                      <pre className="font-mono text-[10.5px] text-emerald-400">
                        {JSON.stringify(computedTotals.ivaTotalPorTasa, null, 2)}
                      </pre>
                    </div>
                  </div>
                </div>

              </div>
            </div>
          </div>
        )}

      </div>

      {/* FOOTER DESCENTRALIZADO */}
      <footer className="py-6 border-t border-slate-850 bg-slate-950 text-center text-xs text-slate-500" id="smart-quote-footer">
        <p>© 2026 Inteligencia Corporativa de Cotizaciones - SmartQuote System</p>
        <p className="mt-1">Diseñado bajo lineamientos y requerimientos de multi-tenancy y flexibilidad de cobros por hora, insumos o fijos.</p>
      </footer>

      {/* MODAL DE ANÁLISIS DE MARGEN (ANALIZAR MARGEN) */}
      <AnimatePresence>
        {isMarginModalOpen && (
          <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 z-50" id="margin-modal">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-slate-900 border border-indigo-950 rounded-2xl max-w-2xl w-full p-6 text-slate-100 shadow-2xl relative overflow-hidden"
            >
              
              {/* Botón de cierre */}
              <button 
                onClick={() => setIsMarginModalOpen(false)}
                className="absolute top-4 right-4 p-1.5 text-slate-400 hover:text-white bg-slate-800/60 rounded-lg cursor-pointer"
              >
                <X className="h-4 w-4" />
              </button>

              <div className="flex items-center gap-2 mb-4 pb-2 border-b border-slate-800">
                <Scale className="h-5 w-5 text-indigo-400" />
                <div>
                  <h3 className="font-bold text-sm tracking-tight text-white uppercase">Análisis Exhaustivo del Margen de Rentabilidad</h3>
                  <p className="text-[11px] text-slate-400">Auditoría financiera en tiempo real - {budgetCode}</p>
                </div>
              </div>

              {/* DETALLES DE CÁLCULO */}
              <div className="space-y-4 text-xs font-mono">
                <div className="bg-slate-950 rounded-xl p-4 border border-slate-800 space-y-2.5">
                  <div className="flex justify-between border-b border-slate-850 pb-1.5 text-slate-400">
                    <span>Variable Métrica</span>
                    <span>Importe Calculado ({budgetCurrency})</span>
                  </div>

                  <div className="flex justify-between">
                    <span className="text-slate-400">(A) Costo Total de Producción:</span>
                    <span className="text-slate-300 font-bold">{computedTotals.costoTotal.toLocaleString()}</span>
                  </div>

                  <div className="flex justify-between">
                    <span className="text-slate-400">(B) Precio de Venta Neto Sugerido:</span>
                    <span className="text-indigo-400 font-bold">
                      {(computedTotals.subtotalVentaTotal / (1 - globalDiscount/100) || 0).toLocaleString()}
                    </span>
                  </div>

                  <div className="flex justify-between text-rose-400">
                    <span>(C) Descuento Global ({globalDiscount}%):</span>
                    <span>-{((computedTotals.subtotalVentaTotal / (1 - globalDiscount/100)) - computedTotals.subtotalVentaTotal || 0).toLocaleString()}</span>
                  </div>

                  <div className="flex justify-between border-t border-slate-850 pt-2 text-indigo-200">
                    <span>(D) Subtotal Neto Realizado (B - C):</span>
                    <span className="font-bold text-indigo-300">{computedTotals.subtotalVentaTotal.toLocaleString()}</span>
                  </div>

                  <div className="flex justify-between text-slate-400">
                    <span>(E) IVA Consolidado Acumulado:</span>
                    <span>+{computedTotals.ivaTotalMasivo.toLocaleString()}</span>
                  </div>

                  <div className="flex justify-between border-t border-indigo-950/60 pt-2 text-white">
                    <span>(F) Precio Final de Venta al Cliente (D + E):</span>
                    <span className="font-black text-emerald-400 text-sm tracking-tight">{computedTotals.precioFinalVenta.toLocaleString()}</span>
                  </div>
                </div>

                {/* DESCRIPCIÓN DEL RETORNO NETO */}
                <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 flex justify-between items-center">
                  <div>
                    <span className="text-[10px] text-slate-500 font-bold block mb-0.5">BENEFICIO NETO DE OPERACIÓN</span>
                    <p className="text-slate-400 text-[10px] uppercase font-bold text-xs">Excedente Neto Recobrado (D - A)</p>
                  </div>
                  <div className="text-right">
                    <span className={`text-xl font-extrabold ${computedTotals.gananciaNetaTotal >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                      {budgetCurrency} {computedTotals.gananciaNetaTotal.toLocaleString()}
                    </span>
                    <span className="block text-[10px] text-slate-300 font-bold">Rentabilidad Real: {computedTotals.margenRealPct}%</span>
                  </div>
                </div>

                {/* Detalle agrupado de IVA */}
                <div className="p-3 bg-slate-900 border border-slate-800 rounded-xl space-y-1">
                  <span className="text-[10px] text-slate-400 font-bold block mb-1">DECLARACIÓN FISCAL POR ALÍCUOTA:</span>
                  <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-300">
                    {Object.entries(computedTotals.ivaTotalPorTasa).map(([tasa, monto]) => (
                      <div key={tasa} className="flex justify-between bg-slate-950/50 p-2 rounded border border-slate-850">
                        <span>Tasa {parseFloat(tasa)}%:</span>
                        <strong className="text-slate-100">{budgetCurrency} {monto.toLocaleString()}</strong>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Recomendación de Negocio en base al Margen */}
                <div className="p-3.5 bg-indigo-950/30 border border-indigo-900/40 rounded-xl flex items-start gap-3">
                  <Info className="h-4.5 w-4.5 text-indigo-400 shrink-0 mt-0.5" />
                  <div className="text-[11px] text-slate-300 font-sans leading-relaxed">
                    <strong>Recomendación Financiera:</strong> {computedTotals.margenRealPct > 25 ? (
                      <span className="text-emerald-300">Este presupuesto cuenta con una excelente salud comercial. Tu margen se encuentra por encima del target mínimo de reventa en servicios de tecnología (25%). Ya puedes proceder a enviarlo con total confianza contable.</span>
                    ) : (
                      <span className="text-amber-400">¡Precaución! Tu margen de ganancia real se ubica por debajo del 25% recomendado para software y servicios altamente calificados. Evalúa ajustar tarifas de horas o reducir el descuento global.</span>
                    )}
                  </div>
                </div>
              </div>

              <div className="mt-5 flex justify-end gap-2 text-xs">
                <button 
                  onClick={() => setIsMarginModalOpen(false)}
                  className="px-5 py-2.5 bg-slate-800 hover:bg-slate-705 text-slate-300 hover:text-white rounded-xl transition cursor-pointer"
                >
                  Entendido, Cerrar Análisis
                </button>
              </div>

            </motion.div>
          </div>
        )}
      </AnimatePresence>

    </div>
  );
}
