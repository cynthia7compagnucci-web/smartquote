-- Active: 1718221600000 -- PostgreSQL Schema for CotizAR Budgeting Module
-- Senior Backend Developer production schema

-- 1. Create Enums for Types and Roles
CREATE TYPE tenant_type AS ENUM ('FREELANCER', 'COMPANY');
CREATE TYPE user_role AS ENUM ('ADMIN', 'VENDEDOR');
CREATE TYPE budget_status AS ENUM ('BORRADOR', 'ENVIADO', 'ACEPTADO', 'RECHAZADO', 'VENCIDO');
CREATE TYPE item_type AS ENUM ('HOURLY', 'MATERIAL', 'FIXED');

-- 2. Create Tenants Table (Multi-tenancy Basis)
CREATE TABLE tenants (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    type tenant_type NOT NULL DEFAULT 'FREELANCER',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL
);

-- 3. Create Users Table
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    name VARCHAR(255) NOT NULL,
    role user_role NOT NULL DEFAULT 'ADMIN',
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    tenant_id UUID NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
    
    CONSTRAINT fk_users_tenant FOREIGN KEY (tenant_id)
        REFERENCES tenants (id) ON DELETE CASCADE
);

-- Index for searching users within a specific tenant quickly
CREATE INDEX idx_users_tenant_id ON users(tenant_id);

-- 4. Create Clients Table
CREATE TABLE clients (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(255) NOT NULL,
    company_name VARCHAR(255),
    email VARCHAR(255) NOT NULL,
    phone VARCHAR(50),
    tax_id VARCHAR(50), -- CUIT/CUIL in Argentina
    address TEXT,
    tenant_id UUID NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
    
    CONSTRAINT fk_clients_tenant FOREIGN KEY (tenant_id)
        REFERENCES tenants (id) ON DELETE CASCADE
);

CREATE INDEX idx_clients_tenant_id ON clients(tenant_id);

-- 5. Create Budgets Table (Header)
CREATE TABLE budgets (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code VARCHAR(100) NOT NULL, -- e.g. COT-2026-0001
    title VARCHAR(255) NOT NULL,
    description TEXT,
    status budget_status NOT NULL DEFAULT 'BORRADOR',
    currency VARCHAR(10) NOT NULL DEFAULT 'ARS',
    exchange_rate NUMERIC(10, 4) NOT NULL DEFAULT 1.0000,
    expiration_date TIMESTAMP WITH TIME ZONE,
    notes TEXT,
    
    -- Consolidated totals (derived for performance, cached from items calculation)
    costo_total NUMERIC(12, 2) NOT NULL DEFAULT 0.00,
    subtotal_venta NUMERIC(12, 2) NOT NULL DEFAULT 0.00,
    iva_total NUMERIC(12, 2) NOT NULL DEFAULT 0.00,
    precio_final NUMERIC(12, 2) NOT NULL DEFAULT 0.00,
    
    tenant_id UUID NOT NULL,
    client_id UUID NOT NULL,
    user_id UUID NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL,
    
    CONSTRAINT fk_budgets_tenant FOREIGN KEY (tenant_id)
        REFERENCES tenants (id) ON DELETE CASCADE,
    CONSTRAINT fk_budgets_client FOREIGN KEY (client_id)
        REFERENCES clients (id) ON DELETE RESTRICT,
    CONSTRAINT fk_budgets_user FOREIGN KEY (user_id)
        REFERENCES users (id) ON DELETE RESTRICT,
        
    -- Business constraint: item code must be unique within a single Tenant
    CONSTRAINT uq_budgets_tenant_code UNIQUE (tenant_id, code),
    
    -- Verification constraints
    CONSTRAINT chk_cost_positive CHECK (costo_total >= 0),
    CONSTRAINT chk_subtotal_positive CHECK (subtotal_venta >= 0),
    CONSTRAINT chk_final_positive CHECK (precio_final >= 0)
);

CREATE INDEX idx_budgets_tenant_id ON budgets(tenant_id);
CREATE INDEX idx_budgets_client_id ON budgets(client_id);
CREATE INDEX idx_budgets_user_id ON budgets(user_id);

-- 6. Create Budget Items Table (Details)
CREATE TABLE budget_items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    budget_id UUID NOT NULL,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    type item_type NOT NULL DEFAULT 'FIXED',
    
    -- Specialty fields for Rubros
    hourly_rate NUMERIC(10, 2),
    hours NUMERIC(7, 2),
    
    unit_cost NUMERIC(12, 2),
    quantity NUMERIC(10, 2),
    unit_label VARCHAR(50) DEFAULT 'unidades',
    
    fixed_cost NUMERIC(12, 2),
    
    -- Financial Core structure
    costo_base NUMERIC(12, 2) NOT NULL,
    margen_ganancia NUMERIC(5, 2) NOT NULL DEFAULT 0.00, -- percentage
    alicuota_iva NUMERIC(4, 2) NOT NULL DEFAULT 21.00,   -- percentage e.g. 21.00, 10.50
    descuento NUMERIC(5, 2) NOT NULL DEFAULT 0.00,       -- percentage e.g. 10.00
    
    -- Isolated calculated fields
    subtotal_venta NUMERIC(12, 2) NOT NULL, -- price with profit and discount, before taxes
    monto_iva NUMERIC(12, 2) NOT NULL,      -- taxes for this item
    precio_final NUMERIC(12, 2) NOT NULL,   -- price with taxes included
    
    CONSTRAINT fk_budget_items_budget FOREIGN KEY (budget_id)
        REFERENCES budgets(id) ON DELETE CASCADE,
        
    -- Financial and rubro mathematical constraints
    CONSTRAINT chk_items_cost_positive CHECK (costo_base >= 0),
    CONSTRAINT chk_items_margin_positive CHECK (margen_ganancia >= 0),
    CONSTRAINT chk_items_discount_range CHECK (descuento >= 0 AND descuento <= 100),
    CONSTRAINT chk_items_iva_positive CHECK (alicuota_iva >= 0)
);

CREATE INDEX idx_budget_items_budget_id ON budget_items(budget_id);

-- 7. Automated Updated At Trigger Function for maintaining Postgres timestamp parity
CREATE OR REPLACE FUNCTION update_modified_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_tenant_modtime BEFORE UPDATE ON tenants FOR EACH ROW EXECUTE PROCEDURE update_modified_column();
CREATE TRIGGER update_user_modtime BEFORE UPDATE ON users FOR EACH ROW EXECUTE PROCEDURE update_modified_column();
CREATE TRIGGER update_client_modtime BEFORE UPDATE ON clients FOR EACH ROW EXECUTE PROCEDURE update_modified_column();
CREATE TRIGGER update_budget_modtime BEFORE UPDATE ON budgets FOR EACH ROW EXECUTE PROCEDURE update_modified_column();
