import React, { useState } from 'react';
import { 
  Cloud, 
  CloudLightning, 
  CloudOff, 
  LogIn, 
  LogOut, 
  Database, 
  RefreshCw, 
  Trash2, 
  FileEdit, 
  ShieldAlert, 
  ShieldCheck, 
  Clock, 
  User, 
  ChevronDown, 
  ChevronUp,
  AlertTriangle
} from 'lucide-react';
import { useFirebase } from '../hooks/useFirebase';
import { Budget } from '../types';
import { BudgetItemInput } from '../utils/budget';

interface FirebaseSyncPanelProps {
  // Budget header
  budgetTitle: string;
  setBudgetTitle: (val: string) => void;
  budgetCode: string;
  setBudgetCode: (val: string) => void;
  budgetCurrency: string;
  setBudgetCurrency: (val: string) => void;
  budgetNotes: string;
  setBudgetNotes: (val: string) => void;
  globalDiscount: number;
  setGlobalDiscount: (val: number) => void;
  // Items list
  items: BudgetItemInput[];
  setItems: (val: BudgetItemInput[]) => void;
  // Tenant and clients
  selectedTenantId: string;
  setSelectedTenantId: (val: string) => void;
  selectedClientId: string;
  setSelectedClientId: (val: string) => void;
}

export default function FirebaseSyncPanel({
  budgetTitle,
  setBudgetTitle,
  budgetCode,
  setBudgetCode,
  budgetCurrency,
  setBudgetCurrency,
  budgetNotes,
  setBudgetNotes,
  globalDiscount,
  setGlobalDiscount,
  items,
  setItems,
  selectedTenantId,
  setSelectedTenantId,
  selectedClientId,
  setSelectedClientId
}: FirebaseSyncPanelProps) {
  const {
    firebaseUser,
    profile,
    loading,
    saving,
    syncLogs,
    diagnosticError,
    firebaseBudgets,
    loadingBudgets,
    signInWithGoogle,
    logout,
    saveBudget,
    deleteBudget,
    reloadBudgets
  } = useFirebase();

  const [showLogs, setShowLogs] = useState(false);

  // Active budget reference to send
  const currentBudgetToSync = {
    id: budgetCode.trim().length > 0 ? `budget-${budgetCode.replace(/[^a-zA-Z0-9_\-]/g, '')}` : `budget-${Date.now()}`,
    title: budgetTitle,
    code: budgetCode,
    currency: budgetCurrency,
    notes: budgetNotes,
    globalDiscount,
    tenantId: profile?.tenantId || selectedTenantId,
    clientId: selectedClientId,
    items
  };

  const handleCloudSave = async () => {
    if (!firebaseUser) {
      await signInWithGoogle();
      return;
    }
    await saveBudget(currentBudgetToSync);
  };

  const handleLoadBudget = (b: Budget) => {
    setBudgetTitle(b.title);
    setBudgetCode(b.code);
    setBudgetCurrency(b.currency);
    setBudgetNotes(b.notes);
    setGlobalDiscount(b.globalDiscount);
    setItems(b.items);
    setSelectedClientId(b.clientId);
    if (b.tenantId) {
      setSelectedTenantId(b.tenantId);
    }
  };

  return (
    <div className="bg-slate-950/70 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-6" id="firebase-sync-panel">
      
      {/* HEADER CARD */}
      <div className="flex items-center justify-between pb-3.5 border-b border-slate-800">
        <div className="flex items-center gap-2">
          {firebaseUser ? (
            <div className="bg-emerald-500/10 p-2 rounded-xl text-emerald-400">
              <Cloud className="h-5 w-5 animate-pulse" />
            </div>
          ) : (
            <div className="bg-slate-800 p-2 rounded-xl text-slate-500">
              <CloudOff className="h-5 w-5" />
            </div>
          )}
          <div>
            <h3 className="font-extrabold text-xs uppercase tracking-wider text-slate-200">Sincronización Nube (Firebase)</h3>
            <p className="text-[10px] text-slate-400">Motor CotizAR de alta velocidad y persistencia</p>
          </div>
        </div>
        
        {/* Status indicator pill */}
        {firebaseUser ? (
          <span className="text-[9px] bg-emerald-500/10 text-emerald-400 font-bold px-2.5 py-1 rounded-full uppercase flex items-center gap-1">
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-ping"></span>
            Cloud Conectado
          </span>
        ) : (
          <span className="text-[9px] bg-slate-800 text-slate-400 font-bold px-2.5 py-1 rounded-full uppercase">
            Desconectado
          </span>
        )}
      </div>

      {/* USER MANAGEMENT SECTION */}
      {loading ? (
        <div className="flex items-center justify-center py-4 gap-2 text-xs text-slate-400">
          <RefreshCw className="h-4 w-4 animate-spin text-indigo-400" />
          <span>Verificando credenciales autorizadas...</span>
        </div>
      ) : !firebaseUser ? (
        <div className="bg-slate-900/60 border border-slate-800/80 p-4 rounded-xl text-center space-y-3.5">
          <p className="text-xs text-slate-300 leading-relaxed max-w-sm mx-auto">
            Conecta tu cuenta corporativa para poder guardar cotizaciones, sincronizar clientes y resguardar presupuestos en tiempo real bajo esquemas de seguridad auditables.
          </p>
          <button
            type="button"
            onClick={signInWithGoogle}
            className="w-full sm:w-auto bg-indigo-600 hover:bg-indigo-500 text-white font-semibold text-xs py-2 px-5 rounded-xl cursor-pointer transition shadow-lg shadow-indigo-600/15 flex items-center justify-center gap-2 mx-auto"
          >
            <LogIn className="h-4 w-4" />
            Iniciar Sesión con Google
          </button>
        </div>
      ) : (
        <div className="bg-slate-900 border border-slate-800/60 p-4 rounded-xl space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="bg-indigo-600 h-9 w-9 rounded-lg flex items-center justify-center font-extrabold text-sm text-white">
                {profile?.avatar || firebaseUser.email?.substring(0, 2).toUpperCase() || 'U'}
              </div>
              <div>
                <h4 className="font-bold text-xs text-slate-200">{profile?.name || firebaseUser.displayName}</h4>
                <p className="text-[10px] text-slate-400 font-mono">{firebaseUser.email}</p>
              </div>
            </div>
            
            <button
              type="button"
              onClick={logout}
              className="text-[11px] text-rose-400 bg-rose-500/10 hover:bg-rose-500/20 px-2.5 py-1 rounded-lg transition flex items-center gap-1"
              title="Cerrar sesión corporativa"
            >
              <LogOut className="h-3 w-3" />
              Salir
            </button>
          </div>

          <div className="grid grid-cols-2 gap-2 text-[10px] bg-slate-950/50 p-2.5 rounded-lg border border-slate-850">
            <div>
              <span className="text-slate-500 block">MARGEN DE ROL:</span>
              <span className="text-indigo-300 font-bold uppercase">{profile?.role || 'VENDEDOR'}</span>
            </div>
            <div>
              <span className="text-slate-500 block">FIRESTORE TENANT:</span>
              <span className="text-emerald-400 font-bold font-mono uppercase">{profile?.tenantId || 't1'}</span>
            </div>
          </div>
        </div>
      )}

      {/* CLOUD SAVE/TRANSACTION ACTUATOR */}
      {firebaseUser && (
        <div className="space-y-3">
          <div className="flex gap-2">
            <button
              type="button"
              onClick={handleCloudSave}
              disabled={saving}
              className="flex-1 bg-gradient-to-r from-emerald-600 to-indigo-600 hover:from-emerald-500 hover:to-indigo-500 text-white font-extrabold text-xs py-2.5 px-4 rounded-xl cursor-pointer transition flex items-center justify-center gap-2 shadow-lg shadow-emerald-950/20 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {saving ? (
                <>
                  <RefreshCw className="h-4 w-4 animate-spin" />
                  Guardando en la nube...
                </>
              ) : (
                <>
                  <Database className="h-4 w-4" />
                  Sincronizar [ {budgetCode || 'NUEVO'} ]
                </>
              )}
            </button>
            
            <button
              type="button"
              onClick={reloadBudgets}
              disabled={loadingBudgets}
              className="bg-slate-900 border border-slate-800 hover:bg-slate-800 p-2.5 rounded-xl text-slate-200 cursor-pointer transition disabled:opacity-50"
              title="Actualizar catálogo guardado"
            >
              <RefreshCw className={`h-4 w-4 ${loadingBudgets ? 'animate-spin text-indigo-400' : ''}`} />
            </button>
          </div>
        </div>
      )}

      {/* SAVED BUDGETS LIST (FIRESTORE DATA SET) */}
      {firebaseUser && (
        <div className="space-y-2">
          <h4 className="text-[10px] tracking-wider font-extrabold text-slate-400 uppercase">Cotizaciones almacenadas en Firestore</h4>
          {loadingBudgets && firebaseBudgets.length === 0 ? (
            <div className="py-6 text-center text-xs text-slate-500 bg-slate-900/40 rounded-xl border border-slate-800/50">
              <RefreshCw className="h-4 w-4 animate-spin text-indigo-500 mx-auto mb-2" />
              Sincronizando carpetas...
            </div>
          ) : firebaseBudgets.length === 0 ? (
            <div className="py-6 text-center text-xs text-slate-500 bg-slate-900/40 rounded-xl border border-slate-800/50">
              No se han encontrado presupuestos en la nube para este usuario.
            </div>
          ) : (
            <div className="max-h-48 overflow-y-auto divide-y divide-slate-850 bg-slate-950 border border-slate-850 rounded-xl text-xs">
              {firebaseBudgets.map((budget) => {
                const isSelected = budget.code === budgetCode;
                return (
                  <div 
                    key={budget.id}
                    className={`p-2.5 flex items-center justify-between gap-2 hover:bg-indigo-950/20 transition ${isSelected ? 'bg-indigo-950/20 border-l-2 border-indigo-500' : ''}`}
                  >
                    <button
                      type="button"
                      onClick={() => handleLoadBudget(budget)}
                      className="flex-1 text-left cursor-pointer outline-none block min-w-0"
                    >
                      <div className="flex items-center gap-1.5">
                        <span className="font-mono font-bold text-indigo-400 shrink-0">{budget.code}</span>
                        <span className="text-[10px] bg-slate-800 text-slate-400 px-1 py-0.2 rounded font-semibold">{budget.currency}</span>
                      </div>
                      <span className="font-semibold text-slate-200 block truncate leading-tight mt-0.5">{budget.title}</span>
                      <span className="text-[9px] text-slate-500 flex items-center gap-1 mt-0.5">
                        <Clock className="w-2.5 h-2.5" />
                        {budget.items.length} ítems
                      </span>
                    </button>
                    
                    <button
                      type="button"
                      onClick={() => deleteBudget(budget.id)}
                      className="p-1 px-1.5 text-slate-500 hover:text-rose-400 hover:bg-rose-500/10 rounded-lg transition"
                      title="Eliminar de Firestore"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* HARDENED FIRESTORE DIAGNOSIS (PILLAR 2 & 10 AUDITING) */}
      {diagnosticError ? (
        <div className="bg-red-950/40 border border-red-900/60 p-3.5 rounded-xl space-y-2.5 text-xs text-red-200 shadow-md">
          <div className="flex items-start gap-2">
            <ShieldAlert className="h-5 w-5 text-red-400 shrink-0 mt-0.5" />
            <div>
              <strong className="text-red-300 block uppercase tracking-wide text-[10px]">Restricción de Seguridad Detectada (Red-Team Blocked)</strong>
              <p className="text-[11px] text-red-400 leading-normal mt-0.5">
                La base de datos denegó la operación porque se vulneraron las políticas Zero-Trust provistas en <code className="bg-red-950 px-1 py-0.5 rounded text-white text-[10px]">firestore.rules</code>.
              </p>
            </div>
          </div>

          <div className="bg-slate-950 p-2.5 rounded-lg border border-red-900/40 text-[10.5px] font-mono text-rose-300 break-all max-h-36 overflow-y-auto">
            {diagnosticError}
          </div>

          <div className="text-[10px] pt-1.5 border-t border-red-900/30 flex items-center gap-1.5 text-red-400">
            <AlertTriangle className="h-3.5 w-3.5" />
            <span>Auditoría de Invariantes: Se protegió al servidor de shadow-fields o mutación ilícita.</span>
          </div>
        </div>
      ) : firebaseUser ? (
        <div className="bg-emerald-950/20 border border-emerald-900/40 p-3 rounded-xl flex items-center gap-2.5 text-xs text-emerald-300">
          <ShieldCheck className="h-4.5 w-4.5 text-emerald-400 shrink-0" />
          <div className="text-[10px] leading-relaxed">
            <strong>Filtro Zero-Trust Cumplido:</strong> Los campos de cotización encajan con precisión quirúrgica en el esquema e integridad impositiva de <code className="text-slate-100 font-mono">firestore.rules</code>.
          </div>
        </div>
      ) : null}

      {/* SYSTEM LOGS SHELL (ARCHITECTURAL HONESTY) */}
      {firebaseUser && (
        <div className="border border-slate-850 rounded-xl overflow-hidden text-xs">
          <button
            type="button"
            onClick={() => setShowLogs(!showLogs)}
            className="w-full bg-slate-900 px-3 py-2 flex items-center justify-between text-slate-400 hover:bg-slate-850 cursor-pointer transition font-medium"
          >
            <span className="flex items-center gap-1.5 uppercase tracking-wider text-[9px] font-bold">
              <CloudLightning className="h-3.5 w-3.5 text-indigo-400 animate-pulse" />
              Historial de Acciones Cloud
            </span>
            {showLogs ? <ChevronUp className="h-3.5 w-3.5" /> : <ChevronDown className="h-3.5 w-3.5" />}
          </button>
          
          {showLogs && (
            <div className="bg-slate-950 p-2 text-[10px] font-mono text-slate-300 h-28 overflow-y-auto divide-y divide-slate-900">
              {syncLogs.length === 0 ? (
                <div className="text-slate-600 text-center py-2">Sin actividad reciente.</div>
              ) : (
                syncLogs.map((log, i) => (
                  <div key={i} className="py-1 leading-normal">{log}</div>
                ))
              )}
            </div>
          )}
        </div>
      )}

    </div>
  );
}
