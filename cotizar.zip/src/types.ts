import { BudgetItemInput } from './utils/budget';

export type TenantType = 'COMPANY' | 'FREELANCER';

export interface Tenant {
  id: string;
  name: string;
  type: TenantType;
  usersCount: number;
}

export interface User {
  id: string;
  name: string;
  role: string;
  tenantId: string;
  avatar: string;
  email?: string;
}

export interface Client {
  id: string;
  name: string;
  companyName: string;
  email: string;
  phone: string;
  taxId: string;
  tenantId: string;
  userId?: string;
}

export interface Budget {
  id: string;
  title: string;
  code: string;
  currency: string;
  notes: string;
  globalDiscount: number;
  tenantId: string;
  userId: string;
  clientId: string;
  items: BudgetItemInput[];
  createdAt?: any;
  updatedAt?: any;
}
