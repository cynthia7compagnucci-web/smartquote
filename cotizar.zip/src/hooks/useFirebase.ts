import { useState, useEffect } from 'react';
import { 
  onAuthStateChanged, 
  signInWithPopup, 
  GoogleAuthProvider, 
  signOut, 
  User as FirebaseUser 
} from 'firebase/auth';
import { 
  doc, 
  setDoc, 
  getDoc, 
  getDocs, 
  collection, 
  query, 
  where, 
  deleteDoc, 
  serverTimestamp 
} from 'firebase/firestore';
import { auth, db, handleFirestoreError, OperationType } from '../firebase';
import { Budget, User, Client, Tenant } from '../types';

export function useFirebase() {
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
  const [profile, setProfile] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [syncLogs, setSyncLogs] = useState<string[]>([]);
  const [diagnosticError, setDiagnosticError] = useState<string | null>(null);
  const [firebaseBudgets, setFirebaseBudgets] = useState<Budget[]>([]);
  const [loadingBudgets, setLoadingBudgets] = useState(false);

  // Sign in using Google Auth with Popup
  const signInWithGoogle = async () => {
    setDiagnosticError(null);
    const provider = new GoogleAuthProvider();
    try {
      const result = await signInWithPopup(auth, provider);
      addLog(`Sign-in exitoso con Google: ${result.user.email}`);
      return result.user;
    } catch (err) {
      console.error(err);
      addLog(`Error al autenticar: ${err instanceof Error ? err.message : String(err)}`);
      setDiagnosticError(err instanceof Error ? err.message : String(err));
      return null;
    }
  };

  // Sign out
  const logout = async () => {
    setDiagnosticError(null);
    try {
      await signOut(auth);
      setProfile(null);
      setFirebaseBudgets([]);
      addLog("Sesión cerrada exitosamente.");
    } catch (err) {
      console.error(err);
      addLog("Error al cerrar sesión.");
    }
  };

  const addLog = (message: string) => {
    const timestamp = new Date().toLocaleTimeString();
    setSyncLogs(prev => [`[${timestamp}] ${message}`, ...prev.slice(0, 49)]);
  };

  // Helper to ensure initial master records (Tenants & Clients) are bootstrapped in Firestore.
  // This allows the server rules to find valid documents for lookups.
  const bootstrapMasterData = async (userUid: string, userTenantId: string) => {
    try {
      addLog("Iniciando inicialización preventiva de datos maestros...");
      
      // 1. Seed Tenant
      const tenantRef = doc(db, 'tenants', userTenantId);
      const tenantSnap = await getDoc(tenantRef);
      if (!tenantSnap.exists()) {
        addLog(`Inicializando documento Maestro Inquilino para: ${userTenantId}...`);
        await setDoc(tenantRef, {
          id: userTenantId,
          name: userTenantId === 't1' ? 'Estudio Creativo Sur' : 'Laura Gómez (Freelancer)',
          type: userTenantId === 't1' ? 'COMPANY' : 'FREELANCER',
          usersCount: userTenantId === 't1' ? 5 : 1
        });
        addLog("Inquilino creado exitosamente.");
      }

      // 2. Seed default Clients
      const clients = [
        { id: 'c1', name: 'Cynthia Compagnucci', companyName: 'Globant Argentina S.A.', email: 'cynthia@globant.com', phone: '+54 11 4843-0000', taxId: '30-71114524-8', tenantId: userTenantId, userId: userUid },
        { id: 'c2', name: 'Andrés Kovalsky', companyName: 'Aluar Aluminio S.A.', email: 'akovalsky@aluar.com.ar', phone: '+54 11 5281-2200', taxId: '30-50004922-1', tenantId: userTenantId, userId: userUid },
        { id: 'c3', name: 'Estudio Jurídico Pereyra', companyName: 'Pereyra & Asociados', email: 'pereyra@derecho.com.ar', phone: '+54 261 423-1122', taxId: '20-18454222-9', tenantId: userTenantId, userId: userUid }
      ];

      for (const client of clients) {
        const clientRef = doc(db, 'clients', client.id);
        const clientSnap = await getDoc(clientRef);
        if (!clientSnap.exists()) {
          addLog(`Inoculando Cliente Maestro: ${client.companyName}...`);
          await setDoc(clientRef, client);
        }
      }
      addLog("Seeding de catálogos maestros completado.");
    } catch (err) {
      console.warn("Bootstrap master warning:", err);
      addLog(`Nota de Seeding: Algunas colecciones maestras ya configuradas en el servidor.`);
    }
  };

  // Create or Update user profile in Firestore
  const syncUserProfile = async (fUser: FirebaseUser) => {
    setDiagnosticError(null);
    const userRef = doc(db, 'users', fUser.uid);
    try {
      const userSnap = await getDoc(userRef);
      if (userSnap.exists()) {
        const existingData = userSnap.data() as User;
        setProfile(existingData);
        addLog(`Perfil de usuario restaurado: Hola ${existingData.name} (${existingData.role})`);
        
        // Ensure masters exist
        await bootstrapMasterData(fUser.uid, existingData.tenantId);
      } else {
        // Enforce a default corporate tenant 't1' (Estudio Creativo Sur)
        const defaultTenantId = 't1'; 
        const nameParts = fUser.displayName?.split(' ') || [];
        const initials = nameParts.map(n => n[0]).join('').substring(0, 2).toUpperCase() || fUser.email?.substring(0, 2).toUpperCase() || 'US';
        
        const newProfile: User = {
          id: fUser.uid,
          name: fUser.displayName || fUser.email?.split('@')[0] || 'Vendedor Inteligente',
          role: 'ADMIN',
          tenantId: defaultTenantId,
          avatar: initials,
          email: fUser.email || undefined
        };

        addLog(`Creando nuevo perfil de usuario con acceso en Firestore para: ${newProfile.name}...`);
        await setDoc(userRef, newProfile);
        setProfile(newProfile);
        addLog(`Perfil de usuario establecido exitosamente para inquilino: ${defaultTenantId}`);

        // Ensure masters exist
        await bootstrapMasterData(fUser.uid, defaultTenantId);
      }
    } catch (err) {
      console.error(err);
      addLog(`Error al sincronizar perfil: ${err instanceof Error ? err.message : String(err)}`);
      handleFirestoreError(err, OperationType.WRITE, `users/${fUser.uid}`);
    }
  };

  // Load budgets for this specific user
  const loadBudgets = async () => {
    if (!auth.currentUser) return;
    setLoadingBudgets(true);
    setDiagnosticError(null);
    const path = 'budgets';
    try {
      addLog("Consultando cotizaciones guardadas en la nube...");
      const q = query(
        collection(db, path),
        where("userId", "==", auth.currentUser.uid)
      );
      
      const querySnapshot = await getDocs(q);
      const budgetsList: Budget[] = [];
      querySnapshot.forEach((docSnap) => {
        const data = docSnap.data();
        budgetsList.push({
          id: docSnap.id,
          title: data.title || '',
          code: data.code || '',
          currency: data.currency || 'USD',
          notes: data.notes || '',
          globalDiscount: data.globalDiscount || 0,
          tenantId: data.tenantId || '',
          userId: data.userId || '',
          clientId: data.clientId || '',
          items: data.items || [],
          createdAt: data.createdAt?.toDate?.() ? data.createdAt.toDate().toISOString() : data.createdAt,
          updatedAt: data.updatedAt?.toDate?.() ? data.updatedAt.toDate().toISOString() : data.updatedAt
        });
      });
      setFirebaseBudgets(budgetsList);
      addLog(`Cotizaciones recuperadas con éxito de Firestore. Total: ${budgetsList.length}`);
    } catch (err) {
      console.error(err);
      addLog(`Error de lectura en Firestore: ${err instanceof Error ? err.message : String(err)}`);
      setDiagnosticError(err instanceof Error ? err.message : String(err));
      try {
        handleFirestoreError(err, OperationType.LIST, path);
      } catch (e) {
        // Log formatted JSON
      }
    } finally {
      setLoadingBudgets(false);
    }
  };

  // Save budget to Firestore
  const saveBudget = async (budgetInput: Omit<Budget, 'userId' | 'createdAt' | 'updatedAt'>) => {
    if (!auth.currentUser || !profile) {
      addLog("Operación denegada. Debe iniciar sesión primero.");
      return false;
    }
    setSaving(true);
    setDiagnosticError(null);
    const path = `budgets/${budgetInput.id}`;
    try {
      addLog(`Iniciando guardado atómico de cotización [${budgetInput.code}]...`);
      
      // Determine if it already exists to preserve createdAt or verify structure
      const docRef = doc(db, 'budgets', budgetInput.id);
      const docSnap = await getDoc(docRef);
      
      const payload: any = {
        ...budgetInput,
        userId: auth.currentUser.uid,
        tenantId: profile.tenantId, // Must match the user's active tenant
        updatedAt: serverTimestamp()
      };

      if (!docSnap.exists()) {
        payload.createdAt = serverTimestamp();
        addLog(`Creando nuevo documento en Firestore...`);
      } else {
        payload.createdAt = docSnap.data().createdAt; // keep createdAt immutable
        addLog(`Actualizando documento existente en Firestore...`);
      }

      await setDoc(docRef, payload);
      addLog(`Cotización [${budgetInput.code}] guardada exitosamente en Firestore.`);
      
      // Reload budgets to refresh list
      await loadBudgets();
      return true;
    } catch (err) {
      console.error(err);
      addLog(`ERROR AL GUARDAR EN FIRESTORE. Ver detalle diagnóstico.`);
      setDiagnosticError(err instanceof Error ? err.message : String(err));
      try {
        handleFirestoreError(err, OperationType.WRITE, path);
      } catch (e) {
        // Log is already printed by handleFirestoreError
      }
      return false;
    } finally {
      setSaving(false);
    }
  };

  // Delete budget
  const deleteBudget = async (budgetId: string) => {
    if (!auth.currentUser) return;
    setDiagnosticError(null);
    const path = `budgets/${budgetId}`;
    try {
      addLog(`Eliminando cotización ${budgetId} de la nube...`);
      await deleteDoc(doc(db, 'budgets', budgetId));
      addLog("Documento eliminado correctamente.");
      await loadBudgets();
      return true;
    } catch (err) {
      console.error(err);
      addLog(`Error al eliminar: ${err instanceof Error ? err.message : String(err)}`);
      setDiagnosticError(err instanceof Error ? err.message : String(err));
      try {
        handleFirestoreError(err, OperationType.DELETE, path);
      } catch (e) {}
      return false;
    }
  };

  // Track Firebase Auth Changes
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (fUser) => {
      setLoading(true);
      if (fUser) {
        setFirebaseUser(fUser);
        addLog(`Usuario de Firebase detectado: ${fUser.email}`);
        await syncUserProfile(fUser);
      } else {
        setFirebaseUser(null);
        setProfile(null);
        setFirebaseBudgets([]);
        addLog("Ningún usuario autenticado.");
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  // Fetch budgets list once profile and login is completed
  useEffect(() => {
    if (firebaseUser && profile) {
      loadBudgets();
    }
  }, [firebaseUser, profile]);

  return {
    firebaseUser,
    profile,
    loading,
    saving,
    syncLogs,
    diagnosticError,
    firebaseBudgets,
    loadingBudgets,
    signInWithGoogle,
    logout,
    saveBudget,
    deleteBudget,
    reloadBudgets: loadBudgets
  };
}
