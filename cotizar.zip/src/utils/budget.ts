/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * Representa los diferentes rubros soportados por el sistema de presupuestos.
 */
export type ItemType = 'HOURLY' | 'MATERIAL' | 'FIXED';

/**
 * Estructura de entrada para un ítem de presupuesto.
 * Contiene la información de costos, ganancias, IVA y descuentos aislados por ítem.
 */
export interface BudgetItemInput {
  id?: string;
  name: string;
  type: ItemType;
  
  // Detalle de rubros (metadatos para auditoría y cálculo de costoBase)
  hourlyRate?: number;    // Costo por hora (Rubro HOURLY)
  hours?: number;         // Cantidad de horas (Rubro HOURLY)
  
  unitCost?: number;      // Costo unitario del material (Rubro MATERIAL)
  quantity?: number;      // Cantidad de materiales (Rubro MATERIAL)
  unitLabel?: string;     // Unidad de medida, ej: "kg", "mts" (Rubro MATERIAL)
  
  fixedCost?: number;     // Precio de costo de mano de obra o precio cerrado (Rubro FIXED)

  // Campos financieros centrales y aislados requeridos por negocio
  costoBase: number;       // Precio de costo del ítem (ej: horas * hourlyRate, o unitCost * quantity, o fixedCost)
  margenGanancia: number;  // Margen de ganancia deseado en porcentaje (ej: 35 para 35%)
  alicuotaIva: number;     // Alícuota de IVA aplicable en porcentaje (ej: 21, 10.5, 0)
  descuento: number;       // Descuento aplicado al ítem en porcentaje (ej: 10 para 10%)
}

/**
 * Estructura del reporte financiero devuelto por el motor de cálculo en tiempo real.
 */
export interface BudgetTotalsReport {
  /** Costo de producción / ejecución acumulado de todos los ítems */
  costoTotal: number;
  
  /** Suma de la ganancia neta generada por el margen de venta (luego de aplicar descuentos, previo a impuestos) */
  gananciaNetaTotal: number;
  
  /** Detalle del IVA acumulado agrupado por alícuota aplicable (ej: { "21": 420.50, "10.5": 110.25 }) */
  ivaTotalPorTasa: Record<string, number>;
  
  /** Suma de todos los IVAs calculados */
  ivaTotalMasivo: number;
  
  /** Subtotal neto de venta (precio sin IVA pero con descuentos aplicados) */
  subtotalVentaTotal: number;
  
  /** Precio final de venta con IVA e impuestos incluidos para el cliente final */
  precioFinalVenta: number;
}

/**
 * Redondea un número a dos decimales de forma segura para evitar errores de precisión decimal IEEE 754.
 */
export function roundToTwoDecimals(num: number): number {
  return Math.round((num + Number.EPSILON) * 100) / 100;
}

/**
 * Función principal para el cálculo en tiempo real de costos, utilidades e impuestos.
 * 
 * Fórmula Financiera aplicada por Ítem:
 * 1. Precio Sugerido Pre-descuento = costoBase * (1 + (margenGanancia / 100))
 * 2. Monto Descuento = Precio Sugerido Pre-descuento * (descuento / 100)
 * 3. Precio Neto de Venta (Subtotal) = Precio Sugerido Pre-descuento - Monto Descuento
 * 4. Ganancia Neta Ítem = Precio Neto de Venta - costoBase
 * 5. Monto IVA = Precio Neto de Venta * (alicuotaIva / 100)
 * 6. Precio Final con IVA = Precio Neto de Venta + Monto IVA
 * 
 * @param items Array de ítems del presupuesto con sus costos, márgenes, IVA y descuentos.
 * @returns Reporte consolidado de totales, ganancias e IVA del presupuesto.
 */
export function calculateBudgetTotals(items: BudgetItemInput[]): BudgetTotalsReport {
  let costoTotal = 0;
  let gananciaNetaTotal = 0;
  let ivaTotalMasivo = 0;
  let subtotalVentaTotal = 0;
  let precioFinalVenta = 0;
  
  const ivaTotalPorTasa: Record<string, number> = {};

  for (const item of items) {
    // 0. Validación y desinfección preventiva de montos
    const costoBase = Math.max(0, item.costoBase || 0);
    const margen = Math.max(0, item.margenGanancia || 0);
    const descuentoPct = Math.max(0, Math.min(100, item.descuento || 0));
    const alicuota = Math.max(0, item.alicuotaIva || 0);

    // 1. Calcular precio de venta sugerido (Costo + Margen)
    const precioSugerido = costoBase * (1 + (margen / 100));

    // 2. Aplicar descuento sobre el precio de venta sugerido
    const montoDescuento = precioSugerido * (descuentoPct / 100);
    const subtotalVentaItem = precioSugerido - montoDescuento;

    // 3. Ganancia neta (Precio Venta Realizado - Costo Base de Producción)
    const gananciaNetaItem = subtotalVentaItem - costoBase;

    // 4. Calcular IVA aplicable sobre el subtotal neto de venta
    const montoIvaItem = subtotalVentaItem * (alicuota / 100);
    const precioFinalItem = subtotalVentaItem + montoIvaItem;

    // Acumular totales crudos para evitar arrastrar errores de redondeo en bucles
    costoTotal += costoBase;
    gananciaNetaTotal += gananciaNetaItem;
    subtotalVentaTotal += subtotalVentaItem;
    ivaTotalMasivo += montoIvaItem;
    precioFinalVenta += precioFinalItem;

    // Agrupar IVA por tasa
    const tasaKey = alicuota.toFixed(1); // ej: "21.0" o "10.5" o "0.0" para mantener formato consistente
    if (!ivaTotalPorTasa[tasaKey]) {
      ivaTotalPorTasa[tasaKey] = 0;
    }
    ivaTotalPorTasa[tasaKey] += montoIvaItem;
  }

  // Redondear los diccionarios de IVA agrupados por tasa
  const ivaAgrupadoRedondeado: Record<string, number> = {};
  for (const [tasa, monto] of Object.entries(ivaTotalPorTasa)) {
    ivaAgrupadoRedondeado[tasa] = roundToTwoDecimals(monto);
  }

  return {
    costoTotal: roundToTwoDecimals(costoTotal),
    gananciaNetaTotal: roundToTwoDecimals(gananciaNetaTotal),
    ivaTotalPorTasa: ivaAgrupadoRedondeado,
    ivaTotalMasivo: roundToTwoDecimals(ivaTotalMasivo),
    subtotalVentaTotal: roundToTwoDecimals(subtotalVentaTotal),
    precioFinalVenta: roundToTwoDecimals(precioFinalVenta)
  };
}
