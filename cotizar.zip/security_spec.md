# Security Specification: SmartQuote Firestore Core

This security spec outlines the zero-trust data constraints, data invariants, and defensive validation rules governing the Firestore database for the SmartQuote application.

## 1. Data Invariants & Zero-Trust Policies
- **Authentication**: All read and write operations require valid user authentication. Anonymous users have no default permissions.
- **Tenant Isolation**: Users can only query, create, or update data (Budgets, Clients, and Tenants) if their user document's `tenantId` field matches the resource's `tenantId`.
- **Budget Pricing Integrity**: During creation or updates, budgets must have logical, validated value sizes and structures:
  - `globalDiscount` must reside strictly in the range `[0, 50]`.
  - Keys and fields must not contain shadow system configurations.
- **Immutable Timestamps**: `createdAt` on budgets must match the server timestamp (`request.time`) upon document creation and remain immutable. `updatedAt` must match the server timestamp during updates.

## 2. The "Dirty Dozen" Security Violations Draft
The following twelve attacks must be synchronously blocked at the Firestore routing engine layer:
1. **Ghost Inquilino Creation**: Spurious tenant registrations by unauthorized or non-registered users.
2. **Identity Hijacking**: A user updates their own profile to map into another company's `tenantId` without permission.
3. **Admin Privilege Escalation**: A normal `VENDEDOR` attempts to update their user record to set `role = "ADMIN"`.
4. **Tenant Data Scraping**: A member of tenant "A" attempts to query client records belonging to tenant "B".
5. **Cross-Tenant Budget Infiltration**: A user updates a budget's `tenantId` parameter to transfer billing metadata under their control.
6. **Malicious ID Injection**: Forcing a 2MB binary string as a budget document ID to trigger wallet denial.
7. **Discount Hijack (Over 50%)**: Injecting a `globalDiscount` value of `99.9%` to zero-out invoice subtotals.
8. **Impersonator Budgets**: Creating a budget document where the `userId` field belongs to another active user.
9. **Retroactive Anti-dating**: Overwriting the `createdAt` timestamp with a past value to bypass corporate compliance.
10. **Shadow Key Inoculation**: Adding unapproved hidden array fields to a budget document to alter pricing execution.
11. **Client Identity Theft**: Deleting or replacing a foreign client profile outside their workspace bounds.
12. **Post-terminal State Corruptions**: Overwriting closed or verified budgets after corporate sign-off (terminal locking).

---

## 3. High-Security Firestore Rules Specification

We will implement complete rules enforcing strict schema matching, size checks, relational synchronization, and temporal tracking.
